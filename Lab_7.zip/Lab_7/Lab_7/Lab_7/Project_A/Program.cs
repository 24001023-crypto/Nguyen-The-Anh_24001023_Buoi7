using System;
using System.Windows.Forms;

namespace Project_A
{
    internal static class Program
    {
        /// <summary>
        /// Điểm khởi chạy chính của ứng dụng
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Màn hình đăng nhập xác thực kết nối CSDL (popup 1 lần như trang đăng nhập)
            // Nhập đúng thông tin và kết nối thành công mới cho phép vào ứng dụng chính
            using (frmDangNhap fLogin = new frmDangNhap())
            {
                if (fLogin.ShowDialog() == DialogResult.OK)
                {
                    Application.Run(new frmMain());
                }
            }
        }
    }
}
