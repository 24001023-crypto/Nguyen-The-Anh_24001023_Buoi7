using System;

namespace Project_A
{
    /// <summary>
    /// Lớp chứa thông tin sinh viên - dùng để truyền dữ liệu giữa các Form và ánh xạ CSDL QLSinhVien
    /// </summary>
    public class SinhVien
    {
        public string MaSV { get; set; }
        public string HoTen { get; set; }
        public DateTime NgaySinh { get; set; }
        public string Khoa { get; set; }
        public string GioiTinh { get; set; }
        public double DiemTB { get; set; }
        public string SoThich { get; set; }
        public string DuongDanAnh { get; set; }
        public string Email { get; set; }

        // Constructor mặc định
        public SinhVien() { }

        // Constructor 4 tham số 
        public SinhVien(string maSV, string hoTen, DateTime ngaySinh, double diemTB)
        {
            MaSV = maSV;
            HoTen = hoTen;
            NgaySinh = ngaySinh;
            DiemTB = diemTB;
            Khoa = "";
            GioiTinh = "Nam";
            SoThich = "";
            DuongDanAnh = "";
            Email = "";
        }

        // Constructor đầy đủ tham số
        public SinhVien(string maSV, string hoTen, DateTime ngaySinh,
                        string khoa, string gioiTinh, double diemTB,
                        string soThich, string duongDanAnh)
        {
            MaSV = maSV;
            HoTen = hoTen;
            NgaySinh = ngaySinh;
            Khoa = khoa;
            GioiTinh = gioiTinh;
            DiemTB = diemTB;
            SoThich = soThich;
            DuongDanAnh = duongDanAnh;
            Email = "";
        }

        // Constructor mở rộng kèm Email
        public SinhVien(string maSV, string hoTen, DateTime ngaySinh,
                        string khoa, string gioiTinh, double diemTB,
                        string soThich, string duongDanAnh, string email)
        {
            MaSV = maSV;
            HoTen = hoTen;
            NgaySinh = ngaySinh;
            Khoa = khoa;
            GioiTinh = gioiTinh;
            DiemTB = diemTB;
            SoThich = soThich;
            DuongDanAnh = duongDanAnh;
            Email = email;
        }
    }
}
