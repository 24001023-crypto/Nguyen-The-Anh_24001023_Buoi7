namespace Project_A
{
    partial class frmTrangThaiKetNoi
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.panelContent = new System.Windows.Forms.Panel();
            this.lblElapsedValue = new System.Windows.Forms.Label();
            this.lblElapsed = new System.Windows.Forms.Label();
            this.lblStateValue = new System.Windows.Forms.Label();
            this.lblState = new System.Windows.Forms.Label();
            this.lblServerVersionValue = new System.Windows.Forms.Label();
            this.lblServerVersion = new System.Windows.Forms.Label();
            this.lblDatabaseValue = new System.Windows.Forms.Label();
            this.lblDatabase = new System.Windows.Forms.Label();
            this.lblDataSourceValue = new System.Windows.Forms.Label();
            this.lblDataSource = new System.Windows.Forms.Label();
            this.lblProtocolValue = new System.Windows.Forms.Label();
            this.lblProtocol = new System.Windows.Forms.Label();
            this.lblStatusValue = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.btnDong = new System.Windows.Forms.Button();
            this.panelContent.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(0, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(464, 40);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "✔ KẾT NỐI CƠ SỞ DỮ LIỆU THÀNH CÔNG";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelContent
            // 
            this.panelContent.BackColor = System.Drawing.Color.White;
            this.panelContent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelContent.Controls.Add(this.lblElapsedValue);
            this.panelContent.Controls.Add(this.lblElapsed);
            this.panelContent.Controls.Add(this.lblStateValue);
            this.panelContent.Controls.Add(this.lblState);
            this.panelContent.Controls.Add(this.lblServerVersionValue);
            this.panelContent.Controls.Add(this.lblServerVersion);
            this.panelContent.Controls.Add(this.lblDatabaseValue);
            this.panelContent.Controls.Add(this.lblDatabase);
            this.panelContent.Controls.Add(this.lblDataSourceValue);
            this.panelContent.Controls.Add(this.lblDataSource);
            this.panelContent.Controls.Add(this.lblProtocolValue);
            this.panelContent.Controls.Add(this.lblProtocol);
            this.panelContent.Controls.Add(this.lblStatusValue);
            this.panelContent.Controls.Add(this.lblStatus);
            this.panelContent.Location = new System.Drawing.Point(16, 52);
            this.panelContent.Name = "panelContent";
            this.panelContent.Size = new System.Drawing.Size(432, 225);
            this.panelContent.TabIndex = 1;
            // 
            // lblElapsedValue
            // 
            this.lblElapsedValue.AutoSize = true;
            this.lblElapsedValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblElapsedValue.ForeColor = System.Drawing.Color.DarkSlateGray;
            this.lblElapsedValue.Location = new System.Drawing.Point(165, 192);
            this.lblElapsedValue.Name = "lblElapsedValue";
            this.lblElapsedValue.Size = new System.Drawing.Size(40, 15);
            this.lblElapsedValue.TabIndex = 13;
            this.lblElapsedValue.Text = "12 ms";
            // 
            // lblElapsed
            // 
            this.lblElapsed.AutoSize = true;
            this.lblElapsed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblElapsed.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.lblElapsed.Location = new System.Drawing.Point(16, 192);
            this.lblElapsed.Name = "lblElapsed";
            this.lblElapsed.Size = new System.Drawing.Size(107, 15);
            this.lblElapsed.TabIndex = 12;
            this.lblElapsed.Text = "Thời gian kết nối:";
            // 
            // lblStateValue
            // 
            this.lblStateValue.AutoSize = true;
            this.lblStateValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStateValue.ForeColor = System.Drawing.Color.SeaGreen;
            this.lblStateValue.Location = new System.Drawing.Point(165, 162);
            this.lblStateValue.Name = "lblStateValue";
            this.lblStateValue.Size = new System.Drawing.Size(41, 15);
            this.lblStateValue.TabIndex = 11;
            this.lblStateValue.Text = "Open";
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.lblState.Location = new System.Drawing.Point(16, 162);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(38, 15);
            this.lblState.TabIndex = 10;
            this.lblState.Text = "State:";
            // 
            // lblServerVersionValue
            // 
            this.lblServerVersionValue.AutoSize = true;
            this.lblServerVersionValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServerVersionValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblServerVersionValue.Location = new System.Drawing.Point(165, 132);
            this.lblServerVersionValue.Name = "lblServerVersionValue";
            this.lblServerVersionValue.Size = new System.Drawing.Size(81, 15);
            this.lblServerVersionValue.TabIndex = 9;
            this.lblServerVersionValue.Text = "15.0.2000.5";
            // 
            // lblServerVersion
            // 
            this.lblServerVersion.AutoSize = true;
            this.lblServerVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblServerVersion.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.lblServerVersion.Location = new System.Drawing.Point(16, 132);
            this.lblServerVersion.Name = "lblServerVersion";
            this.lblServerVersion.Size = new System.Drawing.Size(87, 15);
            this.lblServerVersion.TabIndex = 8;
            this.lblServerVersion.Text = "ServerVersion:";
            // 
            // lblDatabaseValue
            // 
            this.lblDatabaseValue.AutoSize = true;
            this.lblDatabaseValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatabaseValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblDatabaseValue.Location = new System.Drawing.Point(165, 102);
            this.lblDatabaseValue.Name = "lblDatabaseValue";
            this.lblDatabaseValue.Size = new System.Drawing.Size(84, 15);
            this.lblDatabaseValue.TabIndex = 7;
            this.lblDatabaseValue.Text = "QLSinhVien";
            // 
            // lblDatabase
            // 
            this.lblDatabase.AutoSize = true;
            this.lblDatabase.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatabase.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.lblDatabase.Location = new System.Drawing.Point(16, 102);
            this.lblDatabase.Name = "lblDatabase";
            this.lblDatabase.Size = new System.Drawing.Size(63, 15);
            this.lblDatabase.TabIndex = 6;
            this.lblDatabase.Text = "Database:";
            // 
            // lblDataSourceValue
            // 
            this.lblDataSourceValue.AutoSize = true;
            this.lblDataSourceValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataSourceValue.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.lblDataSourceValue.Location = new System.Drawing.Point(165, 72);
            this.lblDataSourceValue.Name = "lblDataSourceValue";
            this.lblDataSourceValue.Size = new System.Drawing.Size(11, 15);
            this.lblDataSourceValue.TabIndex = 5;
            this.lblDataSourceValue.Text = ".";
            // 
            // lblDataSource
            // 
            this.lblDataSource.AutoSize = true;
            this.lblDataSource.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDataSource.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.lblDataSource.Location = new System.Drawing.Point(16, 72);
            this.lblDataSource.Name = "lblDataSource";
            this.lblDataSource.Size = new System.Drawing.Size(75, 15);
            this.lblDataSource.TabIndex = 4;
            this.lblDataSource.Text = "DataSource:";
            // 
            // lblProtocolValue
            // 
            this.lblProtocolValue.AutoSize = true;
            this.lblProtocolValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProtocolValue.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lblProtocolValue.Location = new System.Drawing.Point(165, 42);
            this.lblProtocolValue.Name = "lblProtocolValue";
            this.lblProtocolValue.Size = new System.Drawing.Size(155, 15);
            this.lblProtocolValue.TabIndex = 3;
            this.lblProtocolValue.Text = "Windows Authentication";
            // 
            // lblProtocol
            // 
            this.lblProtocol.AutoSize = true;
            this.lblProtocol.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProtocol.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.lblProtocol.Location = new System.Drawing.Point(16, 42);
            this.lblProtocol.Name = "lblProtocol";
            this.lblProtocol.Size = new System.Drawing.Size(110, 15);
            this.lblProtocol.TabIndex = 2;
            this.lblProtocol.Text = "Giao thức kết nối:";
            // 
            // lblStatusValue
            // 
            this.lblStatusValue.AutoSize = true;
            this.lblStatusValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatusValue.ForeColor = System.Drawing.Color.Green;
            this.lblStatusValue.Location = new System.Drawing.Point(165, 14);
            this.lblStatusValue.Name = "lblStatusValue";
            this.lblStatusValue.Size = new System.Drawing.Size(134, 15);
            this.lblStatusValue.TabIndex = 1;
            this.lblStatusValue.Text = "Kết nối thành công";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(70)))), ((int)(((byte)(70)))), ((int)(((byte)(70)))));
            this.lblStatus.Location = new System.Drawing.Point(16, 14);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(107, 15);
            this.lblStatus.TabIndex = 0;
            this.lblStatus.Text = "Trạng thái (Status):";
            // 
            // btnDong
            // 
            this.btnDong.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnDong.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDong.ForeColor = System.Drawing.Color.White;
            this.btnDong.Location = new System.Drawing.Point(172, 288);
            this.btnDong.Name = "btnDong";
            this.btnDong.Size = new System.Drawing.Size(120, 36);
            this.btnDong.TabIndex = 2;
            this.btnDong.Text = "Tiếp tục";
            this.btnDong.UseVisualStyleBackColor = false;
            this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
            // 
            // frmTrangThaiKetNoi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(244)))), ((int)(((byte)(248)))));
            this.ClientSize = new System.Drawing.Size(464, 335);
            this.Controls.Add(this.btnDong);
            this.Controls.Add(this.panelContent);
            this.Controls.Add(this.lblTitle);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTrangThaiKetNoi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Trạng thái kết nối CSDL";
            this.panelContent.ResumeLayout(false);
            this.panelContent.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel panelContent;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.Label lblStatusValue;
        private System.Windows.Forms.Label lblProtocol;
        private System.Windows.Forms.Label lblProtocolValue;
        private System.Windows.Forms.Label lblDataSource;
        private System.Windows.Forms.Label lblDataSourceValue;
        private System.Windows.Forms.Label lblDatabase;
        private System.Windows.Forms.Label lblDatabaseValue;
        private System.Windows.Forms.Label lblServerVersion;
        private System.Windows.Forms.Label lblServerVersionValue;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.Label lblStateValue;
        private System.Windows.Forms.Label lblElapsed;
        private System.Windows.Forms.Label lblElapsedValue;
        private System.Windows.Forms.Button btnDong;
    }
}
