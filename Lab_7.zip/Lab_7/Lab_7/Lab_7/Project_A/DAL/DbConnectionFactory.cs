using System;
using System.Configuration;
using System.Data.SqlClient;

namespace Project_A.DAL
{
    /// <summary>
    /// Lớp nhà máy tạo kết nối SQL Server (ADO.NET)
    /// Đọc chuỗi kết nối từ App.config qua ConfigurationManager (Mục 8)
    /// Hỗ trợ cả Windows Authentication và SQL Server Authentication (Mục 7)
    /// </summary>
    public static class DbConnectionFactory
    {
        private static string _connectionString;

        /// <summary>
        /// Chuỗi kết nối đang sử dụng, ưu tiên đọc từ App.config bằng ConfigurationManager
        /// </summary>
        public static string ConnectionString
        {
            get
            {
                if (!string.IsNullOrEmpty(_connectionString))
                {
                    return _connectionString;
                }

                try
                {
                    // Mục 8: Đọc chuỗi kết nối từ App.config
                    ConnectionStringSettings setting = ConfigurationManager.ConnectionStrings["QLSinhVienConnection"];
                    if (setting != null && !string.IsNullOrWhiteSpace(setting.ConnectionString))
                    {
                        _connectionString = setting.ConnectionString;
                        return _connectionString;
                    }
                }
                catch
                {
                    // Bỏ qua nếu có lỗi đọc cấu hình để dùng chuỗi dự phòng
                }

                // Chuỗi kết nối dự phòng mặc định (Windows Authentication)
                return @"Data Source=.;Initial Catalog=QLSinhVien;Integrated Security=True";
            }
            set
            {
                _connectionString = value;
            }
        }

        /// <summary>
        /// Tạo mới đối tượng SqlConnection với chuỗi kết nối hiện tại
        /// </summary>
        public static SqlConnection Create()
        {
            return new SqlConnection(ConnectionString);
        }

        /// <summary>
        /// Tạo mới đối tượng SqlConnection với chuỗi kết nối tùy chỉnh
        /// </summary>
        public static SqlConnection Create(string customConnectionString)
        {
            return new SqlConnection(customConnectionString);
        }

        /// <summary>
        /// Lưu chuỗi kết nối mới vào file cấu hình App.config
        /// </summary>
        public static bool SaveConnectionString(string newConnStr)
        {
            try
            {
                _connectionString = newConnStr;
                Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                if (config.ConnectionStrings.ConnectionStrings["QLSinhVienConnection"] != null)
                {
                    config.ConnectionStrings.ConnectionStrings["QLSinhVienConnection"].ConnectionString = newConnStr;
                }
                else
                {
                    config.ConnectionStrings.ConnectionStrings.Add(
                        new ConnectionStringSettings("QLSinhVienConnection", newConnStr, "System.Data.SqlClient"));
                }
                config.Save(ConfigurationSaveMode.Modified);
                ConfigurationManager.RefreshSection("connectionStrings");
                return true;
            }
            catch
            {
                _connectionString = newConnStr;
                return false;
            }
        }
    }
}
