using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace Project_A.DAL
{
    /// <summary>
    /// Lớp DAL truy xuất dữ liệu sinh viên trực tiếp từ cơ sở dữ liệu SQL Server QLSinhVien (ADO.NET)
    /// </summary>
    public class SinhVienDAL
    {
        // Bộ nhớ đệm dự phòng mang dữ liệu mẫu của Lab 7 (nếu chưa bật hoặc chưa tạo SQL Server)
        private static readonly List<SinhVien> _fallbackData = new List<SinhVien>()
        {
            new SinhVien("SV001", "Nguyễn Văn An", new DateTime(2005, 2, 15), "Công nghệ thông tin", "Nam", 8.20, "Lập trình", "", "an@eaut.edu.vn"),
            new SinhVien("SV002", "Trần Thị Bình", new DateTime(2005, 7, 21), "Công nghệ thông tin", "Nữ", 7.40, "Đọc sách", "", "binh@eaut.edu.vn"),
            new SinhVien("SV003", "Lê Văn Cường", new DateTime(2004, 12, 3), "Công nghệ kỹ thuật ô tô", "Nam", 6.80, "Thể thao", "", "cuong@eaut.edu.vn"),
            new SinhVien("SV004", "Phạm Thị Dung", new DateTime(2005, 3, 18), "Kinh tế", "Nữ", 8.50, "Đọc sách", "", "dung@eaut.edu.vn"),
            new SinhVien("SV005", "Hoàng Văn Em", new DateTime(2004, 9, 25), "Công nghệ thông tin", "Nam", 9.10, "Lập trình", "", "em@eaut.edu.vn"),
            new SinhVien("SV006", "Đỗ Thị Giang", new DateTime(2005, 11, 12), "Công nghệ kỹ thuật ô tô", "Nữ", 7.00, "Thể thao", "", "giang@eaut.edu.vn"),
            new SinhVien("SV007", "Vũ Đình Hùng", new DateTime(2004, 5, 30), "Kinh tế", "Nam", 6.50, "Thể thao", "", "hung@eaut.edu.vn"),
            new SinhVien("SV008", "Ngô Mai Hương", new DateTime(2005, 8, 8), "Ngôn ngữ Anh", "Nữ", 8.90, "Đọc sách", "", "huong@eaut.edu.vn"),
            new SinhVien("SV009", "Bùi Quang Khánh", new DateTime(2004, 1, 14), "Công nghệ thông tin", "Nam", 7.80, "Lập trình, Thể thao", "", "khanh@eaut.edu.vn"),
            new SinhVien("SV010", "Đặng Phương Linh", new DateTime(2005, 10, 20), "Ngôn ngữ Anh", "Nữ", 8.00, "Đọc sách", "", "linh@eaut.edu.vn")
        };

        public SinhVienDAL()
        {
        }

        // Chuyển đổi tên khoa sang mã khoa trong CSDL
        private string ChuyenTenKhoaThanhMaKhoa(string tenKhoa)
        {
            if (string.IsNullOrWhiteSpace(tenKhoa)) return "CNTT";
            string lower = tenKhoa.Trim().ToLower();
            if (lower.Contains("thông tin") || lower == "cntt") return "CNTT";
            if (lower.Contains("ô tô") || lower.Contains("o to") || lower == "oto") return "OTO";
            if (lower.Contains("kinh tế") || lower.Contains("kinh te") || lower == "kt") return "KT";
            if (lower.Contains("anh") || lower == "nna") return "NNA";
            return "CNTT";
        }

        /// <summary>
        /// Lấy toàn bộ danh sách sinh viên đồng bộ từ CSDL SQL Server QLSinhVien
        /// </summary>
        public List<SinhVien> GetAll()
        {
            List<SinhVien> list = new List<SinhVien>();

            try
            {
                using (SqlConnection conn = DbConnectionFactory.Create())
                {
                    conn.Open();
                    string sql = @"
                        SELECT sv.MaSV, sv.HoTen, sv.NgaySinh, sv.GioiTinh, 
                               ISNULL(k.TenKhoa, sv.MaKhoa) AS TenKhoa, 
                               sv.DiemTB, sv.Email
                        FROM SinhVien sv
                        LEFT JOIN Khoa k ON sv.MaKhoa = k.MaKhoa
                        ORDER BY sv.MaSV";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string maSV = reader["MaSV"].ToString();
                            string hoTen = reader["HoTen"].ToString();
                            DateTime ngaySinh = Convert.ToDateTime(reader["NgaySinh"]);
                            bool isNam = Convert.ToBoolean(reader["GioiTinh"]);
                            string gioiTinh = isNam ? "Nam" : "Nữ";
                            string khoa = reader["TenKhoa"].ToString();
                            double diemTB = Convert.ToDouble(reader["DiemTB"]);
                            string email = reader["Email"] != DBNull.Value ? reader["Email"].ToString() : "";

                            list.Add(new SinhVien(maSV, hoTen, ngaySinh, khoa, gioiTinh, diemTB, "", "", email));
                        }
                    }
                }

                if (list.Count > 0)
                {
                    return list;
                }
            }
            catch
            {
                // Nếu chưa mở được kết nối CSDL, trả về dữ liệu mẫu Lab 7
            }

            return new List<SinhVien>(_fallbackData);
        }

        /// <summary>
        /// Thêm một sinh viên vào CSDL SQL Server
        /// </summary>
        public void Add(SinhVien sv)
        {
            bool sqlSuccess = false;
            try
            {
                using (SqlConnection conn = DbConnectionFactory.Create())
                {
                    conn.Open();
                    string sql = @"
                        INSERT INTO SinhVien (MaSV, HoTen, NgaySinh, GioiTinh, MaKhoa, DiemTB, Email)
                        VALUES (@MaSV, @HoTen, @NgaySinh, @GioiTinh, @MaKhoa, @DiemTB, @Email)";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaSV", sv.MaSV);
                        cmd.Parameters.AddWithValue("@HoTen", sv.HoTen);
                        cmd.Parameters.AddWithValue("@NgaySinh", sv.NgaySinh);
                        cmd.Parameters.AddWithValue("@GioiTinh", sv.GioiTinh == "Nam" ? 1 : 0);
                        cmd.Parameters.AddWithValue("@MaKhoa", ChuyenTenKhoaThanhMaKhoa(sv.Khoa));
                        cmd.Parameters.AddWithValue("@DiemTB", sv.DiemTB);
                        cmd.Parameters.AddWithValue("@Email", string.IsNullOrEmpty(sv.Email) ? (object)DBNull.Value : sv.Email);

                        cmd.ExecuteNonQuery();
                        sqlSuccess = true;
                    }
                }
            }
            catch
            {
                // Bỏ qua lỗi để cập nhật vào fallbackData
            }

            // Đồng bộ vào bộ nhớ đệm
            _fallbackData.RemoveAll(s => s.MaSV.Equals(sv.MaSV, StringComparison.OrdinalIgnoreCase));
            _fallbackData.Add(sv);
        }

        /// <summary>
        /// Cập nhật thông tin sinh viên vào CSDL SQL Server
        /// </summary>
        public bool Update(SinhVien sv)
        {
            bool sqlSuccess = false;
            try
            {
                using (SqlConnection conn = DbConnectionFactory.Create())
                {
                    conn.Open();
                    string sql = @"
                        UPDATE SinhVien
                        SET HoTen = @HoTen,
                            NgaySinh = @NgaySinh,
                            GioiTinh = @GioiTinh,
                            MaKhoa = @MaKhoa,
                            DiemTB = @DiemTB,
                            Email = @Email
                        WHERE MaSV = @MaSV";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaSV", sv.MaSV);
                        cmd.Parameters.AddWithValue("@HoTen", sv.HoTen);
                        cmd.Parameters.AddWithValue("@NgaySinh", sv.NgaySinh);
                        cmd.Parameters.AddWithValue("@GioiTinh", sv.GioiTinh == "Nam" ? 1 : 0);
                        cmd.Parameters.AddWithValue("@MaKhoa", ChuyenTenKhoaThanhMaKhoa(sv.Khoa));
                        cmd.Parameters.AddWithValue("@DiemTB", sv.DiemTB);
                        cmd.Parameters.AddWithValue("@Email", string.IsNullOrEmpty(sv.Email) ? (object)DBNull.Value : sv.Email);

                        int rows = cmd.ExecuteNonQuery();
                        sqlSuccess = (rows > 0);
                    }
                }
            }
            catch
            {
            }

            int index = _fallbackData.FindIndex(s => s.MaSV.Equals(sv.MaSV, StringComparison.OrdinalIgnoreCase));
            if (index >= 0)
            {
                _fallbackData[index] = sv;
                return true;
            }
            return sqlSuccess;
        }

        /// <summary>
        /// Xóa sinh viên khỏi CSDL SQL Server
        /// </summary>
        public bool Delete(string maSV)
        {
            bool sqlSuccess = false;
            try
            {
                using (SqlConnection conn = DbConnectionFactory.Create())
                {
                    conn.Open();
                    string sql = "DELETE FROM SinhVien WHERE MaSV = @MaSV";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@MaSV", maSV);
                        int rows = cmd.ExecuteNonQuery();
                        sqlSuccess = (rows > 0);
                    }
                }
            }
            catch
            {
            }

            int idx = _fallbackData.FindIndex(s => s.MaSV.Equals(maSV, StringComparison.OrdinalIgnoreCase));
            if (idx >= 0)
            {
                _fallbackData.RemoveAt(idx);
                return true;
            }
            return sqlSuccess;
        }

        /// <summary>
        /// Tìm kiếm sinh viên theo mã hoặc họ tên
        /// </summary>
        public List<SinhVien> Search(string keyword)
        {
            List<SinhVien> list = new List<SinhVien>();
            try
            {
                using (SqlConnection conn = DbConnectionFactory.Create())
                {
                    conn.Open();
                    string sql = @"
                        SELECT sv.MaSV, sv.HoTen, sv.NgaySinh, sv.GioiTinh, 
                               ISNULL(k.TenKhoa, sv.MaKhoa) AS TenKhoa, 
                               sv.DiemTB, sv.Email
                        FROM SinhVien sv
                        LEFT JOIN Khoa k ON sv.MaKhoa = k.MaKhoa
                        WHERE sv.MaSV LIKE @keyword OR sv.HoTen LIKE @keyword
                        ORDER BY sv.MaSV";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@keyword", "%" + keyword.Trim() + "%");
                        using (SqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                string maSV = reader["MaSV"].ToString();
                                string hoTen = reader["HoTen"].ToString();
                                DateTime ngaySinh = Convert.ToDateTime(reader["NgaySinh"]);
                                bool isNam = Convert.ToBoolean(reader["GioiTinh"]);
                                string gioiTinh = isNam ? "Nam" : "Nữ";
                                string khoa = reader["TenKhoa"].ToString();
                                double diemTB = Convert.ToDouble(reader["DiemTB"]);
                                string email = reader["Email"] != DBNull.Value ? reader["Email"].ToString() : "";

                                list.Add(new SinhVien(maSV, hoTen, ngaySinh, khoa, gioiTinh, diemTB, "", "", email));
                            }
                        }
                    }
                }

                if (list.Count > 0) return list;
            }
            catch
            {
            }

            string lower = keyword.ToLower();
            return _fallbackData.Where(s =>
                s.MaSV.ToLower().Contains(lower) ||
                s.HoTen.ToLower().Contains(lower)).ToList();
        }

        /// <summary>
        /// Lấy danh sách sinh viên nhóm theo khoa (hiển thị trên TreeView)
        /// </summary>
        public Dictionary<string, List<SinhVien>> GetGroupByKhoa()
        {
            List<SinhVien> all = GetAll();
            return all.GroupBy(s => s.Khoa)
                      .ToDictionary(g => g.Key, g => g.ToList());
        }
    }
}
