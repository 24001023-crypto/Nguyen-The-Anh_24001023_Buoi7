using System;
using System.Windows.Forms;

namespace Project_A
{
    /// <summary>
    /// Form giới thiệu về ứng dụng
    /// </summary>
    public partial class frmGioiThieu : Form
    {
        public frmGioiThieu()
        {
            InitializeComponent();
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
