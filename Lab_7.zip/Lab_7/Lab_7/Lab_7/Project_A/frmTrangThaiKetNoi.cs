using System;
using System.Drawing;
using System.Windows.Forms;

namespace Project_A
{
    /// <summary>
    /// Form popup hiển thị trạng thái kết nối CSDL khi kết nối thành công (Mục 9)
    /// </summary>
    public partial class frmTrangThaiKetNoi : Form
    {
        public frmTrangThaiKetNoi(string status, string protocol, string dataSource, string database, string serverVersion, string state, long elapsedMs)
        {
            InitializeComponent();

            lblStatusValue.Text = status;
            lblProtocolValue.Text = protocol;
            lblDataSourceValue.Text = dataSource;
            lblDatabaseValue.Text = database;
            lblServerVersionValue.Text = serverVersion;
            lblStateValue.Text = state;
            lblElapsedValue.Text = $"{elapsedMs} ms";
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
