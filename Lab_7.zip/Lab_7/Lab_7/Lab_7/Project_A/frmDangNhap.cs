using System;
using System.Data.SqlClient;
using System.Windows.Forms;
using Project_A.DAL;

namespace Project_A
{
    /// <summary>
    /// Màn hình đăng nhập xác thực kết nối CSDL SQL Server (hiển thị popup 1 lần khi mở ứng dụng)
    /// Hỗ trợ cả Windows Authentication và SQL Server Authentication (Mục 7)
    /// Nhập đúng kết nối được mới cho phép vào ứng dụng chính
    /// </summary>
    public partial class frmDangNhap : Form
    {
        public frmDangNhap()
        {
            InitializeComponent();
        }

        private void frmDangNhap_Load(object sender, EventArgs e)
        {
            // Mặc định chọn Windows Authentication
            cboAuthType.SelectedIndex = 0;
            CapNhatGiaoDienXacThuc();

            // Nạp cấu hình từ App.config nếu có
            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DbConnectionFactory.ConnectionString);
                if (!string.IsNullOrWhiteSpace(builder.DataSource)) txtServer.Text = builder.DataSource;
                if (!string.IsNullOrWhiteSpace(builder.InitialCatalog)) txtDatabase.Text = builder.InitialCatalog;

                if (builder.IntegratedSecurity)
                {
                    cboAuthType.SelectedIndex = 0;
                }
                else
                {
                    cboAuthType.SelectedIndex = 1;
                    txtUsername.Text = builder.UserID;
                    txtPassword.Text = builder.Password;
                }
            }
            catch
            {
                txtServer.Text = ".";
                txtDatabase.Text = "QLSinhVien";
            }
        }

        private void cboAuthType_SelectedIndexChanged(object sender, EventArgs e)
        {
            CapNhatGiaoDienXacThuc();
        }

        private void CapNhatGiaoDienXacThuc()
        {
            bool isSqlAuth = (cboAuthType.SelectedIndex == 1);
            lblUsername.Enabled = isSqlAuth;
            txtUsername.Enabled = isSqlAuth;
            lblPassword.Enabled = isSqlAuth;
            txtPassword.Enabled = isSqlAuth;
        }

        private string TaoChuoiKetNoi()
        {
            string server = string.IsNullOrWhiteSpace(txtServer.Text) ? "." : txtServer.Text.Trim();
            string db = string.IsNullOrWhiteSpace(txtDatabase.Text) ? "QLSinhVien" : txtDatabase.Text.Trim();

            if (cboAuthType.SelectedIndex == 0)
            {
                // Windows Authentication
                return $"Data Source={server};Initial Catalog={db};Integrated Security=True";
            }
            else
            {
                // SQL Server Authentication
                string user = txtUsername.Text.Trim();
                string pass = txtPassword.Text;
                return $"Data Source={server};Initial Catalog={db};User ID={user};Password={pass}";
            }
        }

        private void btnDangNhap_Click(object sender, EventArgs e)
        {
            string connStr = TaoChuoiKetNoi();
            this.Cursor = Cursors.WaitCursor;

            try
            {
                // Thử mở kết nối xác thực
                using (SqlConnection conn = DbConnectionFactory.Create(connStr))
                {
                    conn.Open();
                }

                // Kết nối thành công -> Lưu chuỗi kết nối vào App.config
                DbConnectionFactory.SaveConnectionString(connStr);

                this.Cursor = Cursors.Default;
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (SqlException ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show(
                    "Đăng nhập cơ sở dữ liệu thất bại:\n\n" + ex.Message + "\n\nVui lòng kiểm tra lại tên Server, CSDL hoặc tài khoản/mật khẩu.",
                    "Lỗi đăng nhập",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                // Giữ nguyên giao diện để người dùng sửa lại thông tin đăng nhập
            }
            catch (Exception ex)
            {
                this.Cursor = Cursors.Default;
                MessageBox.Show("Lỗi: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
