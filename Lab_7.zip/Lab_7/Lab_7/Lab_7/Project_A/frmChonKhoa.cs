using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Project_A
{
    /// <summary>
    /// Form chọn khoa - nhận danh sách qua constructor, trả về khoa qua Property
    /// Không dùng biến toàn cục
    /// </summary>
    public partial class frmChonKhoa : Form
    {
        // Property trả về khoa được chọn
        public string KhoaDuocChon { get; private set; }

        // Constructor nhận danh sách khoa từ Form gọi
        public frmChonKhoa(List<string> danhSachKhoa)
        {
            InitializeComponent();
            KhoaDuocChon = "";

            // Nạp danh sách khoa vào ListBox
            foreach (string khoa in danhSachKhoa)
            {
                lstKhoa.Items.Add(khoa);
            }

            // Chọn mặc định dòng đầu tiên
            if (lstKhoa.Items.Count > 0)
                lstKhoa.SelectedIndex = 0;
        }

        // ===== NÚT CHỌN =====
        private void btnChon_Click(object sender, EventArgs e)
        {
            // Kiểm tra đã chọn khoa chưa
            if (lstKhoa.SelectedItem == null)
            {
                MessageBox.Show("Vui lòng chọn một khoa!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Gán khoa được chọn vào Property
            KhoaDuocChon = lstKhoa.SelectedItem.ToString();

            // Trả về OK
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        // ===== NÚT HỦY =====
        private void btnHuy_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        // ===== DOUBLE-CLICK ĐỂ CHỌN NHANH =====
        private void lstKhoa_DoubleClick(object sender, EventArgs e)
        {
            // Double-click vào khoa = nhấn nút Chọn
            btnChon_Click(sender, e);
        }
    }
}
