using System;
using System.Windows.Forms;

namespace Project_A
{
    /// <summary>
    /// Form tìm kiếm - trả kết quả qua Property và DialogResult
    /// </summary>
    public partial class frmTimKiem : Form
    {
        // Property trả về từ khóa tìm kiếm cho Form gọi
        public string TuKhoa { get; private set; }

        public frmTimKiem()
        {
            InitializeComponent();
            TuKhoa = "";
        }

        // ===== NÚT TÌM KIẾM =====
        private void btnTim_Click(object sender, EventArgs e)
        {
            // Kiểm tra từ khóa không được trống
            if (string.IsNullOrWhiteSpace(txtTuKhoa.Text))
            {
                MessageBox.Show("Nhập từ khóa tìm kiếm!", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtTuKhoa.Focus();
                return;
            }

            // Gán từ khóa vào Property để Form gọi lấy được
            TuKhoa = txtTuKhoa.Text.Trim();

            // Trả về DialogResult.OK
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        // ===== NÚT HỦY =====
        private void btnHuy_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        // ===== NHẤN ENTER ĐỂ TÌM =====
        private void txtTuKhoa_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                btnTim_Click(sender, e);
                e.Handled = true; // Không phát tiếng beep
            }
        }
    }
}
