using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_A
{
    public partial class frmSinhVien : Form
    {
        // Khởi tạo tầng nghiệp vụ BUS
        private readonly BUS.SinhVienBUS _bus = new BUS.SinhVienBUS();

        public frmSinhVien()
        {
            InitializeComponent();
        }

        // ===== SỰ KIỆN FORM LOAD =====
        private void frmSinhVien_Load(object sender, EventArgs e)
        {
            // Nạp danh sách các khoa vào ComboBox
            cboKhoa.Items.Add("Công nghệ thông tin");
            cboKhoa.Items.Add("Công nghệ kỹ thuật ô tô");
            cboKhoa.Items.Add("Kinh tế");
            cboKhoa.Items.Add("Ngôn ngữ Anh");
            cboKhoa.DropDownStyle = ComboBoxStyle.DropDownList;
            if (cboKhoa.Items.Count > 0) cboKhoa.SelectedIndex = 0;

            // Mặc định chọn giới tính Nam
            radNam.Checked = true;

            // Cập nhật tuổi ban đầu theo ngày sinh
            dtpNgaySinh_ValueChanged(dtpNgaySinh, EventArgs.Empty);

            // Gắn sự kiện TextChanged cho các TextBox để cập nhật xem trước
            txtMaSV.TextChanged += Input_TextChanged;
            txtHoTen.TextChanged += Input_TextChanged;
            txtDiemTB.TextChanged += Input_TextChanged;

            // Hiển thị sinh viên đầu tiên từ BUS nếu có
            var ds = _bus.GetAll();
            if (ds.Count > 0)
            {
                HienThiSinhVienLenForm(ds[0]);
            }
        }

        // ===== HÀM TÍNH TUỔI =====
        private int TinhTuoi(DateTime ngaySinh)
        {
            int tuoi = DateTime.Today.Year - ngaySinh.Year;
            if (ngaySinh.Date > DateTime.Today.AddYears(-tuoi)) tuoi--;
            return tuoi;
        }

        private void dtpNgaySinh_ValueChanged(object sender, EventArgs e)
        {
            lblTuoi.Text = "Tuổi: " + TinhTuoi(dtpNgaySinh.Value);
        }

        // ===== KIỂM TRA DỮ LIỆU NHẬP (ERRORPROVIDER) =====
        // Tách kiểm tra thành phương thức ValidateInput(), hiển thị icon lỗi cạnh control
        private bool ValidateInput()
        {
            errorProvider1.Clear();
            bool valid = true;

            // 1. Kiểm tra mã sinh viên không được để trống
            if (string.IsNullOrWhiteSpace(txtMaSV.Text))
            {
                errorProvider1.SetError(txtMaSV, "Nhập mã sinh viên");
                valid = false;
            }

            // 2. Kiểm tra họ tên không được để trống
            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                errorProvider1.SetError(txtHoTen, "Nhập họ tên");
                valid = false;
            }

            // 3. Kiểm tra điểm trung bình (phải từ 0 đến 10)
            if (!string.IsNullOrWhiteSpace(txtDiemTB.Text))
            {
                double diem;
                if (!double.TryParse(txtDiemTB.Text, out diem) || diem < 0 || diem > 10)
                {
                    errorProvider1.SetError(txtDiemTB, "Điểm phải từ 0 đến 10");
                    valid = false;
                }
            }

            return valid;
        }

        // ===== GIỚI HẠN KÝ TỰ NHẬP ĐIỂM (KeyPress) =====
        // Chỉ cho phép nhập chữ số và 1 dấu thập phân vào txtDiemTB
        private void txtDiemTB_KeyPress(object sender, KeyPressEventArgs e)
        {
            // Cho phép các phím điều khiển (Backspace, Delete, ...)
            if (char.IsControl(e.KeyChar)) return;

            // Cho phép nhập số
            if (char.IsDigit(e.KeyChar)) return;

            // Cho phép đúng 1 dấu chấm thập phân
            if (e.KeyChar == '.' && !txtDiemTB.Text.Contains(".")) return;

            // Chặn tất cả các ký tự còn lại
            e.Handled = true;
        }

        // ===== CẬP NHẬT TRẠNG THÁI THEO THỜI GIAN THỰC (TextChanged) =====
        // Khi mã, họ tên hoặc điểm thay đổi → cập nhật Label xem trước
        private void Input_TextChanged(object sender, EventArgs e)
        {
            double diem;
            bool hopLe = double.TryParse(txtDiemTB.Text, out diem)
                         && diem >= 0 && diem <= 10;

            // Cập nhật nhãn xem trước: "Mã SV - Họ tên"
            lblXemTruoc.Text = txtMaSV.Text + " - " + txtHoTen.Text;

            // Cập nhật trạng thái hợp lệ của điểm
            lblTrangThai.Text = hopLe ? "Dữ liệu điểm hợp lệ" : "Kiểm tra điểm";
        }

        // ===== SỰ KIỆN KHI ĐỔI KHOA (SelectedIndexChanged) =====
        private void cboKhoa_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblXemTruoc.Text = txtMaSV.Text + " - " + txtHoTen.Text
                             + " (" + cboKhoa.Text + ")";
        }

        // ===== NÚT LƯU SINH VIÊN (Click) =====
        private void btnLuu_Click(object sender, EventArgs e)
        {
            // Kiểm tra dữ liệu đầu vào
            if (!ValidateInput()) return;

            // Lấy giới tính
            string gioiTinh = radNam.Checked ? "Nam" : "Nữ";

            // Lấy điểm trung bình
            double diemTB = 0;
            double.TryParse(txtDiemTB.Text, out diemTB);

            // Lấy sở thích
            List<string> dsSoThich = new List<string>();
            if (chkDocSach.Checked) dsSoThich.Add("Đọc sách");
            if (chkTheThao.Checked) dsSoThich.Add("Thể thao");
            if (chkLapTrinh.Checked) dsSoThich.Add("Lập trình");
            string soThich = dsSoThich.Count == 0 ? "Chưa chọn" : string.Join(", ", dsSoThich);

            // Tạo đối tượng SinhVien
            SinhVien sv = new SinhVien(
                txtMaSV.Text.Trim(),
                txtHoTen.Text.Trim(),
                dtpNgaySinh.Value,
                cboKhoa.Text,
                gioiTinh,
                diemTB,
                soThich,
                txtDuongDanAnh.Text
            );

            // Lưu/cập nhật qua tầng BUS
            try
            {
                if (_bus.GetAll().Any(s => s.MaSV.Equals(sv.MaSV, StringComparison.OrdinalIgnoreCase)))
                {
                    _bus.Update(sv);
                    MessageBox.Show("Đã cập nhật sinh viên: " + sv.HoTen, "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    _bus.Add(sv);
                    MessageBox.Show("Đã lưu sinh viên: " + sv.HoTen + " (Tổng: " + _bus.GetAll().Count + " SV)",
                        "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi nghiệp vụ", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // ===== NÚT XEM CHI TIẾT (Click) =====
        // Truyền đối tượng SinhVien sang frmChiTietSinhVien qua constructor
        private void btnXemChiTiet_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            string gioiTinh = radNam.Checked ? "Nam" : "Nữ";
            double diemTB = 0;
            double.TryParse(txtDiemTB.Text, out diemTB);

            List<string> dsSoThich = new List<string>();
            if (chkDocSach.Checked) dsSoThich.Add("Đọc sách");
            if (chkTheThao.Checked) dsSoThich.Add("Thể thao");
            if (chkLapTrinh.Checked) dsSoThich.Add("Lập trình");
            string soThich = dsSoThich.Count == 0 ? "Chưa chọn" : string.Join(", ", dsSoThich);

            SinhVien sv = new SinhVien(
                txtMaSV.Text.Trim(),
                txtHoTen.Text.Trim(),
                dtpNgaySinh.Value,
                cboKhoa.Text,
                gioiTinh,
                diemTB,
                soThich,
                txtDuongDanAnh.Text
            );

            // Khởi tạo form chi tiết và truyền đối tượng qua constructor
            frmChiTietSinhVien fChiTiet = new frmChiTietSinhVien(sv);
            fChiTiet.ShowDialog();
        }

        // ===== HỘP THOẠI TÌM KIẾM (Click) =====
        // Mở frmTimKiem, nhận từ khóa qua Property TuKhoa và hiển thị thông tin sinh viên
        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            frmTimKiem fTim = new frmTimKiem();
            if (fTim.ShowDialog() == DialogResult.OK)
            {
                string tuKhoa = fTim.TuKhoa.ToLower();

                // Tìm kiếm thông qua tầng BUS
                var dsTim = _bus.Search(tuKhoa);
                SinhVien sv = dsTim.Count > 0 ? dsTim[0] : null;

                if (sv != null)
                {
                    // 1. Đổ dữ liệu sinh viên tìm thấy lên các điều khiển của form
                    HienThiSinhVienLenForm(sv);

                    // 2. Mở trực tiếp Form chi tiết để xem đầy đủ thông tin sinh viên
                    frmChiTietSinhVien fChiTiet = new frmChiTietSinhVien(sv);
                    fChiTiet.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Không tìm thấy sinh viên nào khớp với từ khóa: \"" + fTim.TuKhoa + "\"",
                        "Kết quả tìm kiếm", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        // Phương thức công khai cho phép Menu của frmMain gọi tìm kiếm
        public void ThucHienTimKiem()
        {
            btnTimKiem_Click(this, EventArgs.Empty);
        }

        // Hàm hỗ trợ hiển thị dữ liệu sinh viên lên các điều khiển
        private void HienThiSinhVienLenForm(SinhVien sv)
        {
            txtMaSV.Text = sv.MaSV;
            txtHoTen.Text = sv.HoTen;
            dtpNgaySinh.Value = sv.NgaySinh;
            cboKhoa.SelectedItem = sv.Khoa;
            if (sv.GioiTinh == "Nam") radNam.Checked = true;
            else radNu.Checked = true;
            txtDiemTB.Text = sv.DiemTB.ToString("0.##");
            txtDuongDanAnh.Text = sv.DuongDanAnh;

            // Cập nhật sở thích
            chkDocSach.Checked = sv.SoThich.Contains("Đọc sách");
            chkTheThao.Checked = sv.SoThich.Contains("Thể thao");
            chkLapTrinh.Checked = sv.SoThich.Contains("Lập trình");
            lblSoThich.Text = string.IsNullOrEmpty(sv.SoThich) ? "Chưa chọn" : sv.SoThich;

            // Cập nhật nhãn xem trước
            lblXemTruoc.Text = sv.MaSV + " - " + sv.HoTen;

            // Hiển thị ảnh nếu có đường dẫn
            if (!string.IsNullOrEmpty(sv.DuongDanAnh))
            {
                try
                {
                    picAnh.SizeMode = PictureBoxSizeMode.Zoom;
                    picAnh.ImageLocation = sv.DuongDanAnh;
                }
                catch { }
            }
            else
            {
                picAnh.Image = null;
            }
        }

        // ===== NÚT XEM SỞ THÍCH (Click) =====
        private void btnSoThich_Click(object sender, EventArgs e)
        {
            List<string> ds = new List<string>();
            if (chkDocSach.Checked) ds.Add("Đọc sách");
            if (chkTheThao.Checked) ds.Add("Thể thao");
            if (chkLapTrinh.Checked) ds.Add("Lập trình");
            lblSoThich.Text = ds.Count == 0 ? "Chưa chọn" : string.Join(", ", ds);
        }

        // ===== NÚT CHỌN ẢNH (Click) =====
        private void btnChonAnh_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog dlg = new OpenFileDialog())
            {
                dlg.Filter = "Tệp hình ảnh|*.jpg;*.jpeg;*.png;*.bmp";
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    picAnh.SizeMode = PictureBoxSizeMode.Zoom;
                    picAnh.ImageLocation = dlg.FileName;
                    txtDuongDanAnh.Text = dlg.FileName;
                }
            }
        }

        // ===== SỰ KIỆN FORMCLOSING =====
        // Hỏi xác nhận trước khi đóng form
        private void frmSinhVien_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có muốn đóng form thông tin sinh viên không?",
                "Xác nhận",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            // Nếu người dùng chọn No thì hủy việc đóng form
            if (result == DialogResult.No)
            {
                e.Cancel = true;
            }
        }
    }
}
