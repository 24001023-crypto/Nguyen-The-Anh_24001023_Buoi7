using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;
using Project_A.BUS;
using Project_A.DAL;

namespace Project_A
{
    /// <summary>
    /// Form quản lý danh sách sinh viên
    /// </summary>
    public partial class frmDanhSach : Form
    {
        // Khởi tạo tầng nghiệp vụ BUS
        private readonly SinhVienBUS _bus = new SinhVienBUS();

        // BindingList liên kết với DataGridView
        private BindingList<SinhVien> _dsSinhVien;

        public frmDanhSach()
        {
            InitializeComponent();
        }

        // ===== SỰ KIỆN FORM LOAD =====
        private void frmDanhSach_Load(object sender, EventArgs e)
        {
            // Nạp danh sách khoa vào ComboBox
            cboKhoa.Items.Add("Công nghệ thông tin");
            cboKhoa.Items.Add("Công nghệ kỹ thuật ô tô");
            cboKhoa.Items.Add("Kinh tế");
            cboKhoa.Items.Add("Ngôn ngữ Anh");
            cboKhoa.DropDownStyle = ComboBoxStyle.DropDownList;
            if (cboKhoa.Items.Count > 0) cboKhoa.SelectedIndex = 0;

            // Mặc định chọn giới tính Nam
            radNam.Checked = true;

            // Cấu hình tiêu đề cột và liên kết BindingList với DataGridView
            SetupDataGridView();
            _dsSinhVien = new BindingList<SinhVien>(_bus.GetAll());
            dgvSinhVien.DataSource = _dsSinhVien;

            // Cấu hình ListView dạng Details
            SetupListView();

            // Nạp dữ liệu lên ListView và TreeView
            LoadListView(_dsSinhVien);
            LoadTree(_bus.GetGroupByKhoa());
        }

        // ========== CẤU HÌNH TIÊU ĐỀ CỘT DATAGRIDVIEW ==========
        private void SetupDataGridView()
        {
            dgvSinhVien.AutoGenerateColumns = false;
            dgvSinhVien.Columns.Clear();

            dgvSinhVien.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "MaSV",
                HeaderText = "Mã SV",
                Width = 85
            });
            dgvSinhVien.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "HoTen",
                HeaderText = "Họ và tên",
                Width = 150
            });
            dgvSinhVien.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "NgaySinh",
                HeaderText = "Ngày sinh",
                Width = 95,
                DefaultCellStyle = new DataGridViewCellStyle { Format = "dd/MM/yyyy" }
            });
            dgvSinhVien.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Khoa",
                HeaderText = "Khoa",
                Width = 160
            });
            dgvSinhVien.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "GioiTinh",
                HeaderText = "Giới tính",
                Width = 75
            });
            dgvSinhVien.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "DiemTB",
                HeaderText = "Điểm TB",
                Width = 75,
                DefaultCellStyle = new DataGridViewCellStyle { Format = "N2" }
            });
            dgvSinhVien.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "SoThich",
                HeaderText = "Sở thích",
                Width = 140
            });

            dgvSinhVien.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvSinhVien.ReadOnly = true;
            dgvSinhVien.MultiSelect = false;
        }

        // ========== CẤU HÌNH DATAGRIDVIEW ==========

        // Khi chọn dòng trên DataGridView → đổ dữ liệu lên các TextBox
        private void dgvSinhVien_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvSinhVien.CurrentRow == null) return;
            SinhVien sv = dgvSinhVien.CurrentRow.DataBoundItem as SinhVien;
            if (sv == null) return;

            HienThiSinhVienLenForm(sv);
        }

        // ========== CÁC THAO TÁC THÊM, SỬA, XÓA ==========

        // --- NÚT THÊM ---
        private void btnThem_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                SinhVien sv = TaoSinhVienTuForm();
                _bus.Add(sv);
                RefreshAll();
                MessageBox.Show("Đã thêm sinh viên: " + sv.HoTen, "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // --- NÚT SỬA ---
        private void btnSua_Click(object sender, EventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                SinhVien sv = TaoSinhVienTuForm();
                _bus.Update(sv);
                RefreshAll();
                MessageBox.Show("Đã cập nhật sinh viên: " + sv.HoTen, "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        // --- NÚT XÓA ---
        private void btnXoa_Click(object sender, EventArgs e)
        {
            SinhVien sv = dgvSinhVien.CurrentRow == null ? null
                : dgvSinhVien.CurrentRow.DataBoundItem as SinhVien;

            if (sv == null)
            {
                MessageBox.Show("Chọn sinh viên cần xóa.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            DialogResult result = MessageBox.Show(
                "Bạn có chắc muốn xóa sinh viên " + sv.HoTen + " (" + sv.MaSV + ")?",
                "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                try
                {
                    _bus.Delete(sv.MaSV);
                    RefreshAll();
                    XoaForm();
                    MessageBox.Show("Đã xóa sinh viên.", "Thông báo",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        // ========== CẤU HÌNH LISTVIEW ==========

        private void SetupListView()
        {
            lvSinhVien.View = View.Details;
            lvSinhVien.FullRowSelect = true;
            lvSinhVien.GridLines = true;
            lvSinhVien.Columns.Add("Mã SV", 80);
            lvSinhVien.Columns.Add("Họ tên", 150);
            lvSinhVien.Columns.Add("Khoa", 180);
            lvSinhVien.Columns.Add("Điểm TB", 80);
        }

        private void LoadListView(IEnumerable<SinhVien> data)
        {
            lvSinhVien.Items.Clear();
            foreach (SinhVien sv in data)
            {
                ListViewItem item = new ListViewItem(sv.MaSV);
                item.SubItems.Add(sv.HoTen);
                item.SubItems.Add(sv.Khoa);
                item.SubItems.Add(sv.DiemTB.ToString("N2"));
                item.Tag = sv;
                lvSinhVien.Items.Add(item);
            }
        }

        // Khi chọn item trên ListView → hiển thị chi tiết
        private void lvSinhVien_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count == 0) return;
            SinhVien sv = lvSinhVien.SelectedItems[0].Tag as SinhVien;
            if (sv != null) HienThiSinhVienLenForm(sv);
        }

        // ========== CẤU HÌNH TREEVIEW KHOA - SINH VIÊN ==========

        private void LoadTree(Dictionary<string, List<SinhVien>> data)
        {
            tvKhoa.Nodes.Clear();
            foreach (var group in data)
            {
                TreeNode khoaNode = new TreeNode(group.Key + " (" + group.Value.Count + " SV)");
                khoaNode.Tag = group.Key; // Lưu tên khoa
                foreach (SinhVien sv in group.Value)
                {
                    TreeNode svNode = new TreeNode(sv.MaSV + " - " + sv.HoTen);
                    svNode.Tag = sv; // Lưu đối tượng SinhVien vào Tag
                    khoaNode.Nodes.Add(svNode);
                }
                tvKhoa.Nodes.Add(khoaNode);
            }
            tvKhoa.ExpandAll();
        }

        // Khi chọn node con (sinh viên) trên TreeView → hiển thị chi tiết
        private void tvKhoa_AfterSelect(object sender, TreeViewEventArgs e)
        {
            SinhVien sv = e.Node.Tag as SinhVien;
            if (sv != null)
            {
                HienThiSinhVienLenForm(sv);
            }
        }

        // ========== HÀM HỖ TRỢ ==========

        /// <summary>
        /// Kiểm tra dữ liệu nhập
        /// </summary>
        private bool ValidateInput()
        {
            errorProvider1.Clear();
            bool valid = true;

            if (string.IsNullOrWhiteSpace(txtMaSV.Text))
            {
                errorProvider1.SetError(txtMaSV, "Nhập mã sinh viên");
                valid = false;
            }

            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                errorProvider1.SetError(txtHoTen, "Nhập họ tên");
                valid = false;
            }

            if (!string.IsNullOrWhiteSpace(txtDiemTB.Text))
            {
                double diem;
                if (!double.TryParse(txtDiemTB.Text, out diem) || diem < 0 || diem > 10)
                {
                    errorProvider1.SetError(txtDiemTB, "Điểm phải từ 0 đến 10");
                    valid = false;
                }
            }

            return valid;
        }

        /// <summary>
        /// Tạo đối tượng SinhVien từ dữ liệu trên Form
        /// </summary>
        private SinhVien TaoSinhVienTuForm()
        {
            string gioiTinh = radNam.Checked ? "Nam" : "Nữ";
            double diemTB = 0;
            double.TryParse(txtDiemTB.Text, out diemTB);

            List<string> dsSoThich = new List<string>();
            if (chkDocSach.Checked) dsSoThich.Add("Đọc sách");
            if (chkTheThao.Checked) dsSoThich.Add("Thể thao");
            if (chkLapTrinh.Checked) dsSoThich.Add("Lập trình");
            string soThich = dsSoThich.Count == 0 ? "" : string.Join(", ", dsSoThich);

            return new SinhVien(
                txtMaSV.Text.Trim(),
                txtHoTen.Text.Trim(),
                dtpNgaySinh.Value,
                cboKhoa.Text,
                gioiTinh,
                diemTB,
                soThich,
                ""
            );
        }

        /// <summary>
        /// Hiển thị sinh viên lên các control nhập liệu
        /// </summary>
        private void HienThiSinhVienLenForm(SinhVien sv)
        {
            txtMaSV.Text = sv.MaSV;
            txtHoTen.Text = sv.HoTen;
            dtpNgaySinh.Value = sv.NgaySinh;
            cboKhoa.SelectedItem = sv.Khoa;
            if (sv.GioiTinh == "Nam") radNam.Checked = true;
            else radNu.Checked = true;
            txtDiemTB.Text = sv.DiemTB.ToString("0.##");

            chkDocSach.Checked = sv.SoThich != null && sv.SoThich.Contains("Đọc sách");
            chkTheThao.Checked = sv.SoThich != null && sv.SoThich.Contains("Thể thao");
            chkLapTrinh.Checked = sv.SoThich != null && sv.SoThich.Contains("Lập trình");
        }

        /// <summary>
        /// Xóa dữ liệu trên Form
        /// </summary>
        private void XoaForm()
        {
            txtMaSV.Text = "";
            txtHoTen.Text = "";
            txtDiemTB.Text = "";
            dtpNgaySinh.Value = DateTime.Today;
            if (cboKhoa.Items.Count > 0) cboKhoa.SelectedIndex = 0;
            radNam.Checked = true;
            chkDocSach.Checked = false;
            chkTheThao.Checked = false;
            chkLapTrinh.Checked = false;
            txtMaSV.Focus();
        }

        /// <summary>
        /// Làm mới toàn bộ DataGridView, ListView, TreeView
        /// </summary>
        private void RefreshAll()
        {
            // Cập nhật BindingList cho DataGridView
            _dsSinhVien = new BindingList<SinhVien>(_bus.GetAll());
            dgvSinhVien.DataSource = _dsSinhVien;

            // Cập nhật ListView
            LoadListView(_bus.GetAll());

            // Cập nhật TreeView
            LoadTree(_bus.GetGroupByKhoa());
        }

        // Giới hạn nhập điểm (chỉ số và dấu chấm)
        private void txtDiemTB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar)) return;
            if (char.IsDigit(e.KeyChar)) return;
            if (e.KeyChar == '.' && !txtDiemTB.Text.Contains(".")) return;
            e.Handled = true;
        }

        // Nút Xóa Form (làm trống)
        private void btnXoaForm_Click(object sender, EventArgs e)
        {
            XoaForm();
        }

        // ========== SỰ KIỆN XEM CHI TIẾT ==========

        private void MoFormChiTiet(SinhVien sv)
        {
            if (sv == null)
            {
                MessageBox.Show("Vui lòng chọn một sinh viên.", "Thông báo",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            frmChiTietSinhVien fChiTiet = new frmChiTietSinhVien(sv);
            fChiTiet.ShowDialog();
        }

        private void btnXemChiTiet_Click(object sender, EventArgs e)
        {
            SinhVien sv = dgvSinhVien.CurrentRow == null ? null
                : dgvSinhVien.CurrentRow.DataBoundItem as SinhVien;
            MoFormChiTiet(sv);
        }

        private void dgvSinhVien_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            SinhVien sv = dgvSinhVien.Rows[e.RowIndex].DataBoundItem as SinhVien;
            MoFormChiTiet(sv);
        }

        private void lvSinhVien_DoubleClick(object sender, EventArgs e)
        {
            if (lvSinhVien.SelectedItems.Count == 0) return;
            SinhVien sv = lvSinhVien.SelectedItems[0].Tag as SinhVien;
            MoFormChiTiet(sv);
        }

        private void tvKhoa_NodeMouseDoubleClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            SinhVien sv = e.Node.Tag as SinhVien;
            if (sv != null) MoFormChiTiet(sv);
        }

        // ========== TÌM KIẾM NHANH ==========

        private void btnTimKiem_Click(object sender, EventArgs e)
        {
            string tuKhoa = txtTimKiem.Text.Trim();
            var ketQua = _bus.Search(tuKhoa);

            _dsSinhVien = new BindingList<SinhVien>(ketQua);
            dgvSinhVien.DataSource = _dsSinhVien;
            LoadListView(ketQua);

            if (ketQua.Count == 0)
            {
                MessageBox.Show("Không tìm thấy sinh viên nào khớp với từ khóa: \"" + tuKhoa + "\"",
                    "Kết quả", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnHienTatCa_Click(object sender, EventArgs e)
        {
            txtTimKiem.Text = "";
            RefreshAll();
        }

        private void txtTimKiem_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                btnTimKiem_Click(sender, e);
                e.Handled = true;
            }
        }

        // ===== KIỂM TRA KẾT NỐI SQL SERVER =====
        private void btnKiemTra_Click(object sender, EventArgs e)
        {
            Stopwatch sw = Stopwatch.StartNew();
            try
            {
                using (SqlConnection conn = DbConnectionFactory.Create())
                {
                    conn.Open();
                    sw.Stop();

                    string status = "Kết nối thành công (Open)";
                    string protocol = conn.ConnectionString.IndexOf("Integrated Security", StringComparison.OrdinalIgnoreCase) >= 0
                        ? "Windows Authentication" : "SQL Server Authentication";
                    string dataSource = conn.DataSource;
                    string database = conn.Database;
                    string serverVersion = conn.ServerVersion;
                    string state = conn.State.ToString();
                    long elapsedMs = sw.ElapsedMilliseconds;

                    // Popup hiển thị thông tin trạng thái kết nối Mục 9
                    using (frmTrangThaiKetNoi fStatus = new frmTrangThaiKetNoi(
                        status, protocol, dataSource, database, serverVersion, state, elapsedMs))
                    {
                        fStatus.ShowDialog();
                    }
                }
            }
            catch (SqlException ex)
            {
                sw.Stop();
                MessageBox.Show("Lỗi kết nối cơ sở dữ liệu:\n" + ex.Message,
                    "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                sw.Stop();
                MessageBox.Show("Lỗi: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
