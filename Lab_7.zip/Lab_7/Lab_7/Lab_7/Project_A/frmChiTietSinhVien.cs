using System;
using System.Windows.Forms;

namespace Project_A
{
    /// <summary>
    /// Form chi tiết sinh viên - nhận dữ liệu qua constructor
    /// </summary>
    public partial class frmChiTietSinhVien : Form
    {
        // Lưu đối tượng SinhVien được truyền vào
        private readonly SinhVien _sinhVien;

        // Constructor nhận đối tượng SinhVien
        public frmChiTietSinhVien(SinhVien sinhVien)
        {
            InitializeComponent();
            _sinhVien = sinhVien;
        }

        // Khi form load → hiển thị thông tin sinh viên lên các Label
        private void frmChiTietSinhVien_Load(object sender, EventArgs e)
        {
            lblMa.Text = _sinhVien.MaSV;
            lblHoTen.Text = _sinhVien.HoTen;
            lblNgaySinh.Text = _sinhVien.NgaySinh.ToString("dd/MM/yyyy");
            lblKhoa.Text = _sinhVien.Khoa;
            lblGioiTinh.Text = _sinhVien.GioiTinh;
            lblDiem.Text = _sinhVien.DiemTB.ToString("N2");
            lblDuongDanAnh.Text = _sinhVien.DuongDanAnh;

            // Hiển thị ảnh nếu có đường dẫn
            if (!string.IsNullOrEmpty(_sinhVien.DuongDanAnh))
            {
                try
                {
                    picAnhChiTiet.SizeMode = PictureBoxSizeMode.Zoom;
                    picAnhChiTiet.ImageLocation = _sinhVien.DuongDanAnh;
                }
                catch
                {
                    // Không làm gì nếu ảnh lỗi
                }
            }
        }

        // Nút đóng form
        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
