using System;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Windows.Forms;
using Project_A.DAL;

namespace Project_A
{
    /// <summary>
    /// Form kết nối cơ sở dữ liệu SQL Server (ADO.NET)
    /// Hỗ trợ lựa chọn Windows Authentication và SQL Server Authentication
    /// Khi kết nối thành công, tự động popup trang trạng thái kết nối (Mục 9)
    /// </summary>
    public partial class frmKiemTraKetNoi : Form
    {
        public frmKiemTraKetNoi()
        {
            InitializeComponent();
        }

        private void frmKiemTraKetNoi_Load(object sender, EventArgs e)
        {
            // Mặc định chọn Windows Authentication
            cboAuthType.SelectedIndex = 0;
            CapNhatGiaoDienXacThuc();

            // Phân tích chuỗi kết nối hiện tại để nạp lên giao diện
            try
            {
                SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(DbConnectionFactory.ConnectionString);
                if (!string.IsNullOrWhiteSpace(builder.DataSource)) txtServer.Text = builder.DataSource;
                if (!string.IsNullOrWhiteSpace(builder.InitialCatalog)) txtDatabase.Text = builder.InitialCatalog;

                if (builder.IntegratedSecurity)
                {
                    cboAuthType.SelectedIndex = 0;
                }
                else
                {
                    cboAuthType.SelectedIndex = 1;
                    txtUsername.Text = builder.UserID;
                    txtPassword.Text = builder.Password;
                }
            }
            catch
            {
                txtServer.Text = ".";
                txtDatabase.Text = "QLSinhVien";
            }
        }

        private void cboAuthType_SelectedIndexChanged(object sender, EventArgs e)
        {
            CapNhatGiaoDienXacThuc();
        }

        private void CapNhatGiaoDienXacThuc()
        {
            bool isSqlAuth = (cboAuthType.SelectedIndex == 1);
            lblUsername.Enabled = isSqlAuth;
            txtUsername.Enabled = isSqlAuth;
            lblPassword.Enabled = isSqlAuth;
            txtPassword.Enabled = isSqlAuth;
        }

        private string TaoChuoiKetNoi()
        {
            string server = string.IsNullOrWhiteSpace(txtServer.Text) ? "." : txtServer.Text.Trim();
            string db = string.IsNullOrWhiteSpace(txtDatabase.Text) ? "QLSinhVien" : txtDatabase.Text.Trim();

            if (cboAuthType.SelectedIndex == 0)
            {
                // Windows Authentication
                return $"Data Source={server};Initial Catalog={db};Integrated Security=True";
            }
            else
            {
                // SQL Server Authentication (Mục 7)
                string user = txtUsername.Text.Trim();
                string pass = txtPassword.Text;
                return $"Data Source={server};Initial Catalog={db};User ID={user};Password={pass}";
            }
        }

        private void btnKiemTra_Click(object sender, EventArgs e)
        {
            string connStr = TaoChuoiKetNoi();
            Stopwatch sw = Stopwatch.StartNew();

            try
            {
                // Thử mở kết nối
                using (SqlConnection conn = DbConnectionFactory.Create(connStr))
                {
                    conn.Open();
                    sw.Stop();

                    // Lấy các thông số hiển thị trạng thái (Mục 9)
                    string status = "Kết nối thành công (Open)";
                    string protocol = (cboAuthType.SelectedIndex == 0) ? "Windows Authentication" : "SQL Server Authentication";
                    string dataSource = conn.DataSource;
                    string database = conn.Database;
                    string serverVersion = conn.ServerVersion;
                    string state = conn.State.ToString();
                    long elapsedMs = sw.ElapsedMilliseconds;

                    // Lưu chuỗi kết nối vào App.config và DbConnectionFactory (Mục 8)
                    DbConnectionFactory.SaveConnectionString(connStr);

                    // POPUP hiển thị thông tin trạng thái kết nối theo đúng yêu cầu Mục 9
                    using (frmTrangThaiKetNoi fStatus = new frmTrangThaiKetNoi(
                        status, protocol, dataSource, database, serverVersion, state, elapsedMs))
                    {
                        fStatus.ShowDialog();
                    }

                    // Đóng màn hình cấu hình sau khi kết nối thành công để tiếp tục làm việc
                    this.DialogResult = DialogResult.OK;
                    this.Close();
                }
            }
            catch (SqlException ex)
            {
                sw.Stop();
                MessageBox.Show(
                    "Lỗi kết nối cơ sở dữ liệu:\n" + ex.Message + "\n\nVui lòng kiểm tra lại phương thức kết nối, tên Server, User hoặc Password.",
                    "Kết nối thất bại",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
                // Giữ nguyên giao diện để người dùng nhập lại ("nhập đúng connect đc mới làm tiếp")
            }
            catch (Exception ex)
            {
                sw.Stop();
                MessageBox.Show("Lỗi: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
