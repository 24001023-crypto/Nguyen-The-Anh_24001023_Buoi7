using System;
using System.Collections.Generic;
using System.Linq;
using Project_A.DAL;

namespace Project_A.BUS
{
    /// <summary>
    /// Lớp BUS - xử lý nghiệp vụ sinh viên
    /// Kiểm tra dữ liệu trước khi gọi DAL
    /// </summary>
    public class SinhVienBUS
    {
        private readonly SinhVienDAL _dal = new SinhVienDAL();

        /// <summary>
        /// Lấy toàn bộ danh sách sinh viên
        /// </summary>
        public List<SinhVien> GetAll()
        {
            return _dal.GetAll();
        }

        /// <summary>
        /// Thêm sinh viên với kiểm tra nghiệp vụ
        /// </summary>
        public void Add(SinhVien sv)
        {
            // Kiểm tra mã sinh viên không được trống
            if (string.IsNullOrWhiteSpace(sv.MaSV))
                throw new ArgumentException("Thiếu mã sinh viên.");

            // Kiểm tra họ tên không được trống
            if (string.IsNullOrWhiteSpace(sv.HoTen))
                throw new ArgumentException("Thiếu họ tên sinh viên.");

            // Kiểm tra điểm TB hợp lệ
            if (sv.DiemTB < 0 || sv.DiemTB > 10)
                throw new ArgumentException("Điểm TB phải từ 0 đến 10.");

            // Kiểm tra trùng mã sinh viên
            if (_dal.GetAll().Any(x => x.MaSV.Equals(sv.MaSV, StringComparison.OrdinalIgnoreCase)))
                throw new InvalidOperationException("Trùng mã sinh viên: " + sv.MaSV);

            _dal.Add(sv);
        }

        /// <summary>
        /// Cập nhật sinh viên với kiểm tra nghiệp vụ
        /// </summary>
        public void Update(SinhVien sv)
        {
            if (string.IsNullOrWhiteSpace(sv.MaSV))
                throw new ArgumentException("Thiếu mã sinh viên.");

            if (string.IsNullOrWhiteSpace(sv.HoTen))
                throw new ArgumentException("Thiếu họ tên sinh viên.");

            if (sv.DiemTB < 0 || sv.DiemTB > 10)
                throw new ArgumentException("Điểm TB phải từ 0 đến 10.");

            if (!_dal.Update(sv))
                throw new InvalidOperationException("Không tìm thấy sinh viên cần cập nhật: " + sv.MaSV);
        }

        /// <summary>
        /// Xóa sinh viên theo mã
        /// </summary>
        public void Delete(string maSV)
        {
            if (string.IsNullOrWhiteSpace(maSV))
                throw new ArgumentException("Thiếu mã sinh viên cần xóa.");

            if (!_dal.Delete(maSV))
                throw new InvalidOperationException("Không tìm thấy sinh viên cần xóa: " + maSV);
        }

        /// <summary>
        /// Tìm kiếm sinh viên theo từ khóa
        /// </summary>
        public List<SinhVien> Search(string keyword)
        {
            if (string.IsNullOrWhiteSpace(keyword))
                return _dal.GetAll();

            return _dal.Search(keyword);
        }

        /// <summary>
        /// Lấy danh sách sinh viên nhóm theo khoa (cho TreeView)
        /// </summary>
        public Dictionary<string, List<SinhVien>> GetGroupByKhoa()
        {
            return _dal.GetGroupByKhoa();
        }
    }
}
