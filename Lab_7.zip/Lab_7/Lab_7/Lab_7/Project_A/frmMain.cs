using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Windows.Forms;
using Project_A.DAL;

namespace Project_A
{
    /// <summary>
    /// Dashboard đa Form (Form chính MDI Parent)
    /// Có menu, thanh trạng thái, đồng hồ thời gian thực và quản lý các Form chức năng
    /// </summary>
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        // ===== SỰ KIỆN FORM LOAD =====
        private void frmMain_Load(object sender, EventArgs e)
        {
            // Cập nhật đồng hồ ngay khi mở Form
            lblDongHo.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
            timerDongHo.Start();

            // Mở mặc định Form Danh sách sinh viên khi khởi động
            OpenChildForm(new frmDanhSach());
        }

        // ===== ĐỒNG HỒ THỜI GIAN THỰC =====
        private void timerDongHo_Tick(object sender, EventArgs e)
        {
            lblDongHo.Text = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss");
        }

        // ===== MỞ FORM CON TRONG MDI =====
        private void OpenChildForm(Form child)
        {
            // Duyệt danh sách các Form con đang mở trong MdiChildren
            foreach (Form f in this.MdiChildren)
            {
                // Nếu đã có Form cùng loại → kích hoạt Form đó và giải phóng Form mới
                if (f.GetType() == child.GetType())
                {
                    f.Activate();
                    child.Dispose();
                    lblTrangThai.Text = "Đang kích hoạt: " + f.Text;
                    return;
                }
            }

            // Gán Form cha là Form hiện tại và hiển thị
            child.MdiParent = this;
            child.Show();

            // Cập nhật thanh trạng thái
            lblTrangThai.Text = "Đã mở: " + child.Text;
        }

        // ===== MENU: DANH MỤC > SINH VIÊN =====
        private void mnuSinhVien_Click(object sender, EventArgs e)
        {
            OpenChildForm(new frmSinhVien());
        }

        // ===== MENU: DANH MỤC > KHOA =====
        private void mnuKhoa_Click(object sender, EventArgs e)
        {
            List<string> dsKhoa = new List<string>()
            {
                "Công nghệ thông tin",
                "Công nghệ kỹ thuật ô tô",
                "Kinh tế",
                "Ngôn ngữ Anh"
            };

            // Mở Form chọn khoa
            frmChonKhoa fKhoa = new frmChonKhoa(dsKhoa);
            if (fKhoa.ShowDialog() == DialogResult.OK)
            {
                lblTrangThai.Text = "Đã chọn: " + fKhoa.KhoaDuocChon;
                MessageBox.Show("Khoa được chọn: " + fKhoa.KhoaDuocChon,
                    "Thông tin khoa", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        // ===== MENU: DANH MỤC > DANH SÁCH SV =====
        private void mnuDanhSach_Click(object sender, EventArgs e)
        {
            OpenChildForm(new frmDanhSach());
        }

        // ===== MENU: NGHIỆP VỤ > TÌM KIẾM =====
        private void mnuTimKiem_Click(object sender, EventArgs e)
        {
            // Tìm form sinh viên con đang mở
            frmSinhVien fSV = null;
            foreach (Form f in this.MdiChildren)
            {
                if (f is frmSinhVien)
                {
                    fSV = (frmSinhVien)f;
                    break;
                }
            }

            // Nếu chưa mở thì tạo mới và hiển thị
            if (fSV == null)
            {
                fSV = new frmSinhVien();
                OpenChildForm(fSV);
            }
            else
            {
                fSV.Activate();
            }

            // Kích hoạt tìm kiếm sinh viên
            fSV.ThucHienTimKiem();
        }

        // ===== MENU: HỆ THỐNG > KIỂM TRA KẾT NỐI CSDL =====
        private void mnuKiemTraKetNoi_Click(object sender, EventArgs e)
        {
            Stopwatch sw = Stopwatch.StartNew();
            try
            {
                using (SqlConnection conn = DbConnectionFactory.Create())
                {
                    conn.Open();
                    sw.Stop();

                    string status = "Kết nối thành công (Open)";
                    string protocol = conn.ConnectionString.IndexOf("Integrated Security", StringComparison.OrdinalIgnoreCase) >= 0
                        ? "Windows Authentication" : "SQL Server Authentication";
                    string dataSource = conn.DataSource;
                    string database = conn.Database;
                    string serverVersion = conn.ServerVersion;
                    string state = conn.State.ToString();
                    long elapsedMs = sw.ElapsedMilliseconds;

                    lblTrangThai.Text = $"CSDL: {database} ({dataSource}) - Đã kết nối ({DateTime.Now:HH:mm:ss})";

                    using (frmTrangThaiKetNoi fStatus = new frmTrangThaiKetNoi(
                        status, protocol, dataSource, database, serverVersion, state, elapsedMs))
                    {
                        fStatus.ShowDialog();
                    }
                }
            }
            catch (SqlException ex)
            {
                sw.Stop();
                MessageBox.Show("Lỗi kết nối cơ sở dữ liệu:\n" + ex.Message,
                    "Lỗi kết nối", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                sw.Stop();
                MessageBox.Show("Lỗi: " + ex.Message, "Thông báo lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ===== MENU: HỆ THỐNG > ĐỔI TÀI KHOẢN KẾT NỐI CSDL =====
        private void mnuDoiKetNoi_Click(object sender, EventArgs e)
        {
            using (frmDangNhap fLogin = new frmDangNhap())
            {
                if (fLogin.ShowDialog() == DialogResult.OK)
                {
                    lblTrangThai.Text = "CSDL: Đã cập nhật kết nối mới (" + DateTime.Now.ToString("HH:mm:ss") + ")";
                    MessageBox.Show("Cập nhật kết nối CSDL thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        // ===== MENU: HỆ THỐNG > GIỚI THIỆU =====
        private void mnuGioiThieu_Click(object sender, EventArgs e)
        {
            frmGioiThieu f = new frmGioiThieu();
            f.ShowDialog();
        }

        // ===== MENU: HỆ THỐNG > THOÁT =====
        private void mnuThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // ===== XÁC NHẬN ĐÓNG ỨNG DỤNG =====
        // Bắt FormClosing, hỏi xác nhận và hủy đóng nếu người dùng chọn No
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show(
                "Bạn có chắc chắn muốn đóng ứng dụng không?",
                "Xác nhận thoát",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (result == DialogResult.No)
            {
                e.Cancel = true; // Không đóng form
            }
        }
    }
}
