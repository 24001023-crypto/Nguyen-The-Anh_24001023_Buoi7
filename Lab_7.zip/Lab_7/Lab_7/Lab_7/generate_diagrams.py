import os
from PIL import Image, ImageDraw, ImageFont

font_regular_path = '/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf'
font_bold_path = '/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf'

def get_font(path, size):
    return ImageFont.truetype(path, size)

out_dir = "/home/kirin/Bản tải về/Lab_7/Images"
os.makedirs(out_dir, exist_ok=True)

# ==============================================================================
# IMAGE 1: SƠ ĐỒ QUAN HỆ CSDL (ER DIAGRAM)
# ==============================================================================
def draw_er_diagram():
    W, H = 1400, 920
    im = Image.new("RGB", (W, H), (248, 250, 252))
    draw = ImageDraw.Draw(im)

    font_title = get_font(font_bold_path, 24)
    font_sub = get_font(font_regular_path, 15)
    font_tbl_header = get_font(font_bold_path, 18)
    font_col_name = get_font(font_bold_path, 14)
    font_col_type = get_font(font_regular_path, 13)
    font_badge = get_font(font_bold_path, 11)
    font_note = get_font(font_regular_path, 13)

    # Header banner
    draw.rectangle([0, 0, W, 80], fill=(30, 41, 59))
    draw.text((40, 16), "SƠ ĐỒ QUAN HỆ CƠ SỞ DỮ LIỆU - QLSinhVien", font=font_title, fill=(241, 245, 249))
    draw.text((40, 48), "Mô hình quan hệ 4 bảng: Khoa, SinhVien, HocPhan, DangKy", font=font_sub, fill=(148, 163, 184))

    def draw_table(x, y, w, title, columns, header_color=(37, 99, 235)):
        row_h = 32
        hdr_h = 42
        total_h = hdr_h + len(columns) * row_h
        
        draw.rounded_rectangle([x+4, y+4, x+w+4, y+total_h+4], radius=8, fill=(226, 232, 240))
        draw.rounded_rectangle([x, y, x+w, y+total_h], radius=8, fill=(255, 255, 255), outline=(203, 213, 225), width=2)
        
        draw.rounded_rectangle([x, y, x+w, y+hdr_h], radius=8, fill=header_color)
        draw.rectangle([x, y+hdr_h-8, x+w, y+hdr_h], fill=header_color)
        draw.text((x+16, y+10), title, font=font_tbl_header, fill=(255, 255, 255))
        
        curr_y = y + hdr_h
        for i, col in enumerate(columns):
            bg = (248, 250, 252) if i % 2 == 1 else (255, 255, 255)
            draw.rectangle([x+1, curr_y, x+w-1, curr_y+row_h], fill=bg)
            draw.line([x+1, curr_y, x+w-1, curr_y], fill=(241, 245, 249), width=1)
            
            badge = col.get("badge", "")
            bx = x + 12
            if badge == "PK":
                draw.rounded_rectangle([bx, curr_y+6, bx+28, curr_y+24], radius=4, fill=(234, 179, 8))
                draw.text((bx+6, curr_y+7), "PK", font=font_badge, fill=(113, 63, 18))
            elif badge == "FK":
                draw.rounded_rectangle([bx, curr_y+6, bx+28, curr_y+24], radius=4, fill=(59, 130, 246))
                draw.text((bx+6, curr_y+7), "FK", font=font_badge, fill=(255, 255, 255))
            elif badge == "PK,FK":
                draw.rounded_rectangle([bx, curr_y+6, bx+46, curr_y+24], radius=4, fill=(168, 85, 247))
                draw.text((bx+4, curr_y+7), "PK,FK", font=font_badge, fill=(255, 255, 255))
            
            name_x = bx + (54 if badge == "PK,FK" else 36 if badge else 10)
            draw.text((name_x, curr_y+7), col["name"], font=font_col_name, fill=(15, 23, 42))
            
            type_text = col["type"]
            draw.text((x+w-180, curr_y+8), type_text, font=font_col_type, fill=(100, 116, 139))
            
            curr_y += row_h
        return {"x": x, "y": y, "w": w, "h": total_h, "hdr_h": hdr_h}

    cols_khoa = [
        {"badge": "PK", "name": "MaKhoa", "type": "VARCHAR(10)"},
        {"badge": "", "name": "TenKhoa", "type": "NVARCHAR(100) [UNIQUE]"}
    ]
    pos_khoa = draw_table(80, 130, 360, "Khoa", cols_khoa, header_color=(15, 118, 110))

    cols_sv = [
        {"badge": "PK", "name": "MaSV", "type": "VARCHAR(15)"},
        {"badge": "", "name": "HoTen", "type": "NVARCHAR(100)"},
        {"badge": "", "name": "NgaySinh", "type": "DATE"},
        {"badge": "", "name": "GioiTinh", "type": "BIT (1:Nam, 0:Nữ)"},
        {"badge": "FK", "name": "MaKhoa", "type": "VARCHAR(10)"},
        {"badge": "", "name": "DiemTB", "type": "DECIMAL(4,2) [0..10]"},
        {"badge": "", "name": "Email", "type": "VARCHAR(100) [UNIQUE]"}
    ]
    pos_sv = draw_table(80, 330, 420, "SinhVien", cols_sv, header_color=(37, 99, 235))

    cols_hp = [
        {"badge": "PK", "name": "MaHP", "type": "VARCHAR(10)"},
        {"badge": "", "name": "TenHP", "type": "NVARCHAR(120)"},
        {"badge": "", "name": "SoTinChi", "type": "INT [1..6]"}
    ]
    pos_hp = draw_table(900, 130, 400, "HocPhan", cols_hp, header_color=(180, 83, 9))

    cols_dk = [
        {"badge": "PK,FK", "name": "MaSV", "type": "VARCHAR(15)"},
        {"badge": "PK,FK", "name": "MaHP", "type": "VARCHAR(10)"},
        {"badge": "", "name": "NgayDangKy", "type": "DATE [DF: GETDATE()]"},
        {"badge": "", "name": "HocKy", "type": "INT [1..3]"},
        {"badge": "", "name": "Diem", "type": "DECIMAL(4,2) [0..10]"}
    ]
    pos_dk = draw_table(760, 390, 450, "DangKy", cols_dk, header_color=(124, 58, 237))

    # Connectors
    k_x = pos_khoa["x"] + 200
    k_y = pos_khoa["y"] + pos_khoa["h"]
    sv_x = pos_sv["x"] + 200
    sv_y = pos_sv["y"]
    draw.line([k_x, k_y, k_x, sv_y], fill=(13, 148, 136), width=3)
    draw.text((k_x+8, k_y+10), "1", font=font_tbl_header, fill=(13, 148, 136))
    draw.text((sv_x+8, sv_y-30), "∞ (N)", font=font_tbl_header, fill=(13, 148, 136))

    sv_right_x = pos_sv["x"] + pos_sv["w"]
    sv_right_y = pos_sv["y"] + 65
    dk_left_x = pos_dk["x"]
    dk_left_y = pos_dk["y"] + 65
    draw.line([sv_right_x, sv_right_y, dk_left_x, dk_left_y], fill=(37, 99, 235), width=3)
    draw.text((sv_right_x+10, sv_right_y-25), "1", font=font_tbl_header, fill=(37, 99, 235))
    draw.text((dk_left_x-45, dk_left_y-25), "∞ (N)", font=font_tbl_header, fill=(37, 99, 235))

    hp_bot_x = pos_hp["x"] + 200
    hp_bot_y = pos_hp["y"] + pos_hp["h"]
    dk_top_x = pos_dk["x"] + 340
    dk_top_y = pos_dk["y"]
    draw.line([hp_bot_x, hp_bot_y, hp_bot_x, hp_bot_y+80, dk_top_x, hp_bot_y+80, dk_top_x, dk_top_y], fill=(180, 83, 9), width=3)
    draw.text((hp_bot_x+8, hp_bot_y+10), "1", font=font_tbl_header, fill=(180, 83, 9))
    draw.text((dk_top_x+8, dk_top_y-30), "∞ (N)", font=font_tbl_header, fill=(180, 83, 9))

    draw.rounded_rectangle([80, 690, 1300, 870], radius=8, fill=(255, 255, 255), outline=(203, 213, 225), width=2)
    draw.text((105, 705), "RÀNG BUỘC & MỐI QUAN HỆ TRONG CƠ SỞ DỮ LIỆU QLSinhVien:", font=font_tbl_header, fill=(30, 41, 59))
    
    notes = [
        "• Khoa (1) ───< SinhVien (N): Khóa ngoại MaKhoa tham chiếu Khoa(MaKhoa).",
        "• SinhVien (1) ───< DangKy (N) >─── (1) HocPhan: Quan hệ Nhiều - Nhiều thông qua bảng trung gian DangKy.",
        "• Khóa chính phức hợp: Bảng DangKy có khóa chính (MaSV, MaHP).",
        "• Ràng buộc toàn vẹn: UNIQUE(Email), DEFAULT GETDATE() cho ngày đăng ký, CHECK HocKy ∈ [1,3], CHECK Diem ∈ [0,10]."
    ]
    for idx, nt in enumerate(notes):
        draw.text((105, 745 + idx * 28), nt, font=font_note, fill=(71, 85, 105))

    im.save(os.path.join(out_dir, "SoDoQuanHe_CSDL.png"))
    print("Saved SoDoQuanHe_CSDL.png")

# ==============================================================================
# IMAGE 2: KẾT QUẢ TRUY VẤN DỮ LIỆU MẪU (QUERY RESULTS)
# ==============================================================================
def draw_query_results():
    W, H = 1400, 1050
    im = Image.new("RGB", (W, H), (241, 245, 249))
    draw = ImageDraw.Draw(im)

    font_title = get_font(font_bold_path, 22)
    font_sub = get_font(font_regular_path, 14)
    font_sec = get_font(font_bold_path, 15)
    font_th = get_font(font_bold_path, 13)
    font_td = get_font(font_regular_path, 13)

    draw.rectangle([0, 0, W, 75], fill=(15, 23, 42))
    draw.text((40, 15), "KẾT QUẢ TRUY VẤN CƠ SỞ DỮ LIỆU QLSinhVien", font=font_title, fill=(255, 255, 255))
    draw.text((40, 45), "Dữ liệu mẫu nạp vào CSDL SQL Server (4 Khoa, 10 Sinh viên, 6 Học phần, 17 Đăng ký)", font=font_sub, fill=(148, 163, 184))

    def draw_grid(x, y, w, title, headers, rows, col_widths):
        hdr_h = 30
        row_h = 26
        total_h = hdr_h + len(rows) * row_h
        
        draw.text((x, y-24), title, font=font_sec, fill=(30, 41, 59))
        draw.rectangle([x, y, x+w, y+total_h], fill=(255, 255, 255), outline=(203, 213, 225), width=1)
        
        draw.rectangle([x, y, x+w, y+hdr_h], fill=(234, 239, 245))
        draw.line([x, y+hdr_h, x+w, y+hdr_h], fill=(203, 213, 225), width=1)
        
        curr_x = x
        for i, h_text in enumerate(headers):
            draw.text((curr_x+8, y+7), h_text, font=font_th, fill=(51, 65, 85))
            curr_x += col_widths[i]
            if i < len(headers) - 1:
                draw.line([curr_x, y, curr_x, y+total_h], fill=(226, 232, 240), width=1)
        
        curr_y = y + hdr_h
        for r_idx, r in enumerate(rows):
            bg = (250, 252, 255) if r_idx % 2 == 1 else (255, 255, 255)
            draw.rectangle([x+1, curr_y, x+w-1, curr_y+row_h], fill=bg)
            draw.line([x, curr_y+row_h, x+w, curr_y+row_h], fill=(241, 245, 249), width=1)
            
            c_x = x
            for c_idx, cell in enumerate(r):
                draw.text((c_x+8, curr_y+5), str(cell), font=font_td, fill=(15, 23, 42))
                c_x += col_widths[c_idx]
            curr_y += row_h

    # 1. Khoa
    headers_khoa = ["MaKhoa", "TenKhoa"]
    rows_khoa = [
        ["CNTT", "Công nghệ thông tin"],
        ["OTO",  "Công nghệ kỹ thuật ô tô"],
        ["KT",   "Kinh tế"],
        ["NNA",  "Ngôn ngữ Anh"]
    ]
    draw_grid(50, 115, 450, "1. Bảng Khoa", headers_khoa, rows_khoa, [120, 330])

    # 2. HocPhan
    headers_hp = ["MaHP", "TenHP", "SoTinChi"]
    rows_hp = [
        ["HP001", "Lập trình .NET", "3"],
        ["HP002", "Cơ sở dữ liệu", "3"],
        ["HP003", "Cấu trúc dữ liệu và giải thuật", "3"],
        ["HP004", "Lập trình hướng đối tượng", "3"],
        ["HP005", "Kiến trúc máy tính", "2"],
        ["HP006", "Tiếng Anh chuyên ngành CNTT", "2"]
    ]
    draw_grid(550, 115, 800, "2. Bảng HocPhan", headers_hp, rows_hp, [110, 540, 150])

    # 3. SinhVien
    headers_sv = ["MaSV", "HoTen", "NgaySinh", "GioiTinh", "MaKhoa", "DiemTB", "Email"]
    rows_sv = [
        ["SV001", "Nguyễn Văn An",   "2005-02-15", "1 (Nam)", "CNTT", "8.20", "an@eaut.edu.vn"],
        ["SV002", "Trần Thị Bình",   "2005-07-21", "0 (Nữ)",  "CNTT", "7.40", "binh@eaut.edu.vn"],
        ["SV003", "Lê Văn Cường",    "2004-12-03", "1 (Nam)", "OTO",  "6.80", "cuong@eaut.edu.vn"],
        ["SV004", "Phạm Thị Dung",   "2005-03-18", "0 (Nữ)",  "KT",   "8.50", "dung@eaut.edu.vn"],
        ["SV005", "Hoàng Văn Em",    "2004-09-25", "1 (Nam)", "CNTT", "9.10", "em@eaut.edu.vn"],
        ["SV006", "Đỗ Thị Giang",    "2005-11-12", "0 (Nữ)",  "OTO",  "7.00", "giang@eaut.edu.vn"],
        ["SV007", "Vũ Đình Hùng",    "2004-05-30", "1 (Nam)", "KT",   "6.50", "hung@eaut.edu.vn"],
        ["SV008", "Ngô Mai Hương",   "2005-08-08", "0 (Nữ)",  "NNA",  "8.90", "huong@eaut.edu.vn"],
        ["SV009", "Bùi Quang Khánh", "2004-01-14", "1 (Nam)", "CNTT", "7.80", "khanh@eaut.edu.vn"],
        ["SV010", "Đặng Phương Linh","2005-10-20", "0 (Nữ)",  "NNA",  "8.00", "linh@eaut.edu.vn"]
    ]
    draw_grid(50, 335, 1300, "3. Bảng SinhVien (10 sinh viên)", headers_sv, rows_sv, [100, 230, 130, 110, 110, 110, 510])

    # 4. DangKy
    headers_dk = ["MaSV", "HoTen", "TenKhoa", "TenHP", "TinChi", "HocKy", "NgayDangKy", "Diem"]
    rows_dk = [
        ["SV001", "Nguyễn Văn An", "Công nghệ thông tin", "Lập trình .NET", "3", "1", "2024-09-05", "8.50"],
        ["SV001", "Nguyễn Văn An", "Công nghệ thông tin", "Cơ sở dữ liệu", "3", "1", "2024-09-05", "8.00"],
        ["SV002", "Trần Thị Bình", "Công nghệ thông tin", "Lập trình .NET", "3", "1", "2024-09-05", "7.50"],
        ["SV003", "Lê Văn Cường",  "Công nghệ kỹ thuật ô tô", "Cơ sở dữ liệu", "3", "1", "2024-09-06", "6.50"],
        ["SV004", "Phạm Thị Dung", "Kinh tế", "Cơ sở dữ liệu", "3", "1", "2024-09-06", "8.50"],
        ["SV005", "Hoàng Văn Em",  "Công nghệ thông tin", "Lập trình .NET", "3", "1", "2024-09-05", "9.50"],
        ["SV008", "Ngô Mai Hương", "Ngôn ngữ Anh", "Tiếng Anh chuyên ngành CNTT", "2", "1", "2024-09-07", "9.00"]
    ]
    draw_grid(50, 725, 1300, "4. Bảng DangKy (Kết quả liên kết sinh viên và môn học)", headers_dk, rows_dk, [90, 200, 220, 290, 80, 80, 140, 200])

    im.save(os.path.join(out_dir, "KetQuaTruyVan_DauRa.png"))
    print("Saved KetQuaTruyVan_DauRa.png")

# ==============================================================================
# IMAGE 3: GIAO DIỆN KẾT NỐI & POPUP TRẠNG THÁI KẾT NỐI (MỤC 9)
# ==============================================================================
def draw_ui_mockup():
    W, H = 1000, 580
    im = Image.new("RGB", (W, H), (235, 240, 246))
    draw = ImageDraw.Draw(im)

    font_window_title = get_font(font_bold_path, 13)
    font_lbl = get_font(font_regular_path, 12)
    font_txt = get_font(font_regular_path, 12)
    font_btn = get_font(font_bold_path, 12)
    font_status_title = get_font(font_bold_path, 13)
    font_status_val = get_font(font_bold_path, 12)

    # ==========================
    # FORM 1: Kết nối cơ sở dữ liệu (Trái)
    # ==========================
    f1_x, f1_y, f1_w, f1_h = 40, 60, 420, 360
    draw.rounded_rectangle([f1_x+4, f1_y+4, f1_x+f1_w+4, f1_y+f1_h+4], radius=6, fill=(195, 205, 218))
    draw.rounded_rectangle([f1_x, f1_y, f1_x+f1_w, f1_y+f1_h], radius=6, fill=(248, 250, 252), outline=(160, 175, 195), width=2)

    # Title bar Form 1 (Popup Đăng nhập CSDL khi mở ứng dụng)
    draw.rounded_rectangle([f1_x, f1_y, f1_x+f1_w, f1_y+32], radius=6, fill=(225, 233, 245))
    draw.rectangle([f1_x, f1_y+22, f1_x+f1_w, f1_y+32], fill=(225, 233, 245))
    draw.text((f1_x+12, f1_y+8), "Đăng nhập CSDL (Xác thực khi khởi động)", font=font_window_title, fill=(30, 41, 59))
    draw.rectangle([f1_x+f1_w-28, f1_y+6, f1_x+f1_w-8, f1_y+26], fill=(239, 68, 68))
    draw.text((f1_x+f1_w-22, f1_y+8), "✕", font=font_window_title, fill=(255, 255, 255))

    # Input Fields
    inputs = [
        ("Xác thực (Auth):", "Windows Authentication  ▼"),
        ("Máy chủ (Server):", "."),
        ("Cơ sở dữ liệu:", "QLSinhVien"),
        ("Tên đăng nhập:", "sv_app_user"),
        ("Mật khẩu:", "●●●●●●●●")
    ]
    cur_y = f1_y + 55
    for i, inp in enumerate(inputs):
        draw.text((f1_x+20, cur_y+3), inp[0], font=font_lbl, fill=(71, 85, 105))
        # Textbox
        bg = (240, 243, 248) if i >= 3 else (255, 255, 255)
        draw.rectangle([f1_x+160, cur_y, f1_x+f1_w-25, cur_y+26], fill=bg, outline=(180, 195, 215), width=1)
        draw.text((f1_x+170, cur_y+5), inp[1], font=font_txt, fill=(15, 23, 42) if i < 3 else (148, 163, 184))
        cur_y += 45

    # Buttons Form 1
    draw.rectangle([f1_x+80, cur_y+15, f1_x+250, cur_y+52], fill=(37, 99, 235))
    draw.text((f1_x+115, cur_y+24), "Đăng nhập", font=font_btn, fill=(255, 255, 255))

    draw.rectangle([f1_x+270, cur_y+15, f1_x+370, cur_y+52], fill=(120, 130, 145))
    draw.text((f1_x+305, cur_y+24), "Thoát", font=font_btn, fill=(255, 255, 255))

    # ==========================
    # FORM 2: Popup Trạng thái kết nối CSDL (Mục 9) (Bấm từ dock hoặc menu)
    # ==========================
    f2_x, f2_y, f2_w, f2_h = 500, 70, 460, 440
    draw.rounded_rectangle([f2_x+6, f2_y+6, f2_x+f2_w+6, f2_y+f2_h+6], radius=6, fill=(160, 175, 195))
    draw.rounded_rectangle([f2_x, f2_y, f2_x+f2_w, f2_y+f2_h], radius=6, fill=(245, 248, 252), outline=(130, 145, 170), width=2)

    # Title bar
    draw.rounded_rectangle([f2_x, f2_y, f2_x+f2_w, f2_y+32], radius=6, fill=(225, 233, 245))
    draw.rectangle([f2_x, f2_y+22, f2_x+f2_w, f2_y+32], fill=(225, 233, 245))
    draw.text((f2_x+14, f2_y+8), "Trạng thái kết nối CSDL (Kiểm tra từ Dock)", font=font_window_title, fill=(30, 41, 59))

    # Green Banner
    draw.rectangle([f2_x, f2_y+32, f2_x+f2_w, f2_y+75], fill=(46, 125, 50))
    draw.text((f2_x+35, f2_y+44), "✔ KẾT NỐI CƠ SỞ DỮ LIỆU THÀNH CÔNG", font=font_status_title, fill=(255, 255, 255))

    # Content Panel
    px, py, pw, ph = f2_x+15, f2_y+90, f2_w-30, 275
    draw.rectangle([px, py, px+pw, py+ph], fill=(255, 255, 255), outline=(210, 220, 235), width=1)

    status_rows = [
        ("Trạng thái (Status):", "Kết nối thành công (Open)", (46, 125, 50)),
        ("Giao thức kết nối:", "Windows Authentication", (37, 99, 235)),
        ("DataSource (Máy chủ):", ".", (15, 23, 42)),
        ("Database (CSDL):", "QLSinhVien", (15, 23, 42)),
        ("ServerVersion (Phiên bản):", "15.0.2000.5", (15, 23, 42)),
        ("Trạng thái (State):", "Open", (46, 125, 50)),
        ("Thời gian kết nối:", "12 ms", (100, 116, 139))
    ]
    cur_py = py + 15
    for r in status_rows:
        draw.text((px+20, cur_py), r[0], font=font_lbl, fill=(71, 85, 105))
        draw.text((px+180, cur_py), r[1], font=font_status_val, fill=r[2])
        cur_py += 35

    # Button Close
    draw.rectangle([f2_x+170, f2_y+f2_h-55, f2_x+290, f2_y+f2_h-18], fill=(37, 99, 235))
    draw.text((f2_x+210, f2_y+f2_h-44), "Đóng", font=font_btn, fill=(255, 255, 255))

    # Connection arrow between form 1 and popup
    draw.line([f1_x+f1_w, f1_y+200, f2_x, f2_y+200], fill=(37, 99, 235), width=3)
    draw.polygon([(f2_x, f2_y+200), (f2_x-12, f2_y+194), (f2_x-12, f2_y+206)], fill=(37, 99, 235))

    im.save(os.path.join(out_dir, "GiaoDien_KiemTraKetNoi.png"))
    print("Saved GiaoDien_KiemTraKetNoi.png")

if __name__ == "__main__":
    draw_er_diagram()
    draw_query_results()
    draw_ui_mockup()
    print("All diagrams updated cleanly!")
