-- =======================================================================
-- TRƯỜNG ĐẠI HỌC CÔNG NGHỆ ĐÔNG Á
-- KHOA CÔNG NGHỆ THÔNG TIN - BỘ MÔN CÔNG NGHỆ PHẦN MỀM
-- HỌC PHẦN: LẬP TRÌNH .NET (IT3212)
-- LAB 7: TẠO CSDL SQL SERVER, TỔNG QUAN ADO.NET VÀ KẾT NỐI CSDL
-- 
-- Tệp kịch bản: Lab07_QLSinhVien.sql
-- Mô tả: Kịch bản khởi tạo CSDL QLSinhVien, các bảng, khóa chính,
--        khóa ngoại, các ràng buộc toàn vẹn, dữ liệu mẫu, kiểm thử
--        ràng buộc, cấp quyền SQL Auth, và sao lưu/phục hồi.
-- Có thể thực thi từ đầu trên môi trường SQL Server mới.
-- =======================================================================

USE master;
GO

-- =======================================================================
-- 1. TẠO CƠ SỞ DỮ LIỆU QLSinhVien
-- =======================================================================
IF DB_ID(N'QLSinhVien') IS NULL
BEGIN
    PRINT N'-- Đang tạo cơ sở dữ liệu QLSinhVien...';
    CREATE DATABASE QLSinhVien;
END
ELSE
BEGIN
    PRINT N'-- Cơ sở dữ liệu QLSinhVien đã tồn tại.';
END
GO

USE QLSinhVien;
GO

-- Xóa bảng theo thứ tự khóa ngoại nếu đã tồn tại để tránh xung đột khi chạy lại
IF OBJECT_ID(N'dbo.DangKy', N'U') IS NOT NULL DROP TABLE dbo.DangKy;
IF OBJECT_ID(N'dbo.SinhVien', N'U') IS NOT NULL DROP TABLE dbo.SinhVien;
IF OBJECT_ID(N'dbo.HocPhan', N'U') IS NOT NULL DROP TABLE dbo.HocPhan;
IF OBJECT_ID(N'dbo.Khoa', N'U') IS NOT NULL DROP TABLE dbo.Khoa;
GO

-- =======================================================================
-- 2. TẠO BẢNG Khoa VÀ SinhVien
-- =======================================================================

-- 2.1 Bảng Khoa
PRINT N'-- Tạo bảng Khoa...';
CREATE TABLE Khoa
(
    MaKhoa VARCHAR(10) PRIMARY KEY,
    TenKhoa NVARCHAR(100) NOT NULL UNIQUE
);
GO

-- 2.2 Bảng SinhVien (Bổ sung UNIQUE Email theo Bài tập 6)
PRINT N'-- Tạo bảng SinhVien...';
CREATE TABLE SinhVien
(
    MaSV VARCHAR(15) PRIMARY KEY,
    HoTen NVARCHAR(100) NOT NULL,
    NgaySinh DATE NOT NULL,
    GioiTinh BIT NOT NULL,                          -- 1: Nam, 0: Nữ
    MaKhoa VARCHAR(10) NOT NULL,
    DiemTB DECIMAL(4,2) NOT NULL DEFAULT 0,
    Email VARCHAR(100) NULL,
    CONSTRAINT CK_SinhVien_Diem CHECK (DiemTB BETWEEN 0 AND 10),
    CONSTRAINT UQ_SinhVien_Email UNIQUE (Email),   -- Bài tập 6: UNIQUE Email
    CONSTRAINT FK_SinhVien_Khoa FOREIGN KEY (MaKhoa) REFERENCES Khoa(MaKhoa)
);
GO

-- =======================================================================
-- 3. TẠO BẢNG HocPhan VÀ DangKy
-- =======================================================================

-- 3.1 Bảng HocPhan
PRINT N'-- Tạo bảng HocPhan...';
CREATE TABLE HocPhan
(
    MaHP VARCHAR(10) PRIMARY KEY,
    TenHP NVARCHAR(120) NOT NULL,
    SoTinChi INT NOT NULL CONSTRAINT CK_HocPhan_TinChi CHECK (SoTinChi BETWEEN 1 AND 6)
);
GO

-- 3.2 Bảng DangKy (Bổ sung DEFAULT NgayDangKy và CHECK HocKy theo Bài tập 6)
PRINT N'-- Tạo bảng DangKy...';
CREATE TABLE DangKy
(
    MaSV VARCHAR(15) NOT NULL,
    MaHP VARCHAR(10) NOT NULL,
    NgayDangKy DATE NOT NULL CONSTRAINT DF_DangKy_Ngay DEFAULT GETDATE(), -- Bài tập 6: DEFAULT ngày đăng ký
    HocKy INT NOT NULL CONSTRAINT CK_DangKy_HocKy CHECK (HocKy BETWEEN 1 AND 3), -- Bài tập 6: CHECK học kỳ 1-3
    Diem DECIMAL(4,2) NULL CONSTRAINT CK_DangKy_Diem CHECK (Diem BETWEEN 0 AND 10),
    CONSTRAINT PK_DangKy PRIMARY KEY (MaSV, MaHP),
    CONSTRAINT FK_DangKy_SinhVien FOREIGN KEY (MaSV) REFERENCES SinhVien(MaSV) ON DELETE CASCADE,
    CONSTRAINT FK_DangKy_HocPhan FOREIGN KEY (MaHP) REFERENCES HocPhan(MaHP) ON DELETE CASCADE
);
GO

-- =======================================================================
-- 4. THÊM DỮ LIỆU MẪU (Tối thiểu 3 Khoa, 10 Sinh viên, 5 Học phần)
-- =======================================================================

PRINT N'-- Chèn dữ liệu mẫu bảng Khoa (4 khoa)...';
INSERT INTO Khoa (MaKhoa, TenKhoa) VALUES
('CNTT', N'Công nghệ thông tin'),
('OTO',  N'Công nghệ kỹ thuật ô tô'),
('KT',   N'Kinh tế'),
('NNA',  N'Ngôn ngữ Anh');
GO

PRINT N'-- Chèn dữ liệu mẫu bảng SinhVien (10 sinh viên)...';
INSERT INTO SinhVien (MaSV, HoTen, NgaySinh, GioiTinh, MaKhoa, DiemTB, Email) VALUES
('SV001', N'Nguyễn Văn An',   '2005-02-15', 1, 'CNTT', 8.20, 'an@eaut.edu.vn'),
('SV002', N'Trần Thị Bình',   '2005-07-21', 0, 'CNTT', 7.40, 'binh@eaut.edu.vn'),
('SV003', N'Lê Văn Cường',    '2004-12-03', 1, 'OTO',  6.80, 'cuong@eaut.edu.vn'),
('SV004', N'Phạm Thị Dung',   '2005-03-18', 0, 'KT',   8.50, 'dung@eaut.edu.vn'),
('SV005', N'Hoàng Văn Em',    '2004-09-25', 1, 'CNTT', 9.10, 'em@eaut.edu.vn'),
('SV006', N'Đỗ Thị Giang',    '2005-11-12', 0, 'OTO',  7.00, 'giang@eaut.edu.vn'),
('SV007', N'Vũ Đình Hùng',    '2004-05-30', 1, 'KT',   6.50, 'hung@eaut.edu.vn'),
('SV008', N'Ngô Mai Hương',   '2005-08-08', 0, 'NNA',  8.90, 'huong@eaut.edu.vn'),
('SV009', N'Bùi Quang Khánh', '2004-01-14', 1, 'CNTT', 7.80, 'khanh@eaut.edu.vn'),
('SV010', N'Đặng Phương Linh','2005-10-20', 0, 'NNA',  8.00, 'linh@eaut.edu.vn');
GO

PRINT N'-- Chèn dữ liệu mẫu bảng HocPhan (6 học phần)...';
INSERT INTO HocPhan (MaHP, TenHP, SoTinChi) VALUES
('HP001', N'Lập trình .NET', 3),
('HP002', N'Cơ sở dữ liệu', 3),
('HP003', N'Cấu trúc dữ liệu và giải thuật', 3),
('HP004', N'Lập trình hướng đối tượng', 3),
('HP005', N'Kiến trúc máy tính', 2),
('HP006', N'Tiếng Anh chuyên ngành CNTT', 2);
GO

PRINT N'-- Chèn dữ liệu mẫu bảng DangKy...';
INSERT INTO DangKy (MaSV, MaHP, NgayDangKy, HocKy, Diem) VALUES
('SV001', 'HP001', '2024-09-05', 1, 8.50),
('SV001', 'HP002', '2024-09-05', 1, 8.00),
('SV001', 'HP003', '2025-01-15', 2, 8.20),
('SV002', 'HP001', '2024-09-05', 1, 7.50),
('SV002', 'HP002', '2024-09-05', 1, 7.00),
('SV003', 'HP002', '2024-09-06', 1, 6.50),
('SV003', 'HP005', '2025-01-16', 2, 7.00),
('SV004', 'HP002', '2024-09-06', 1, 8.50),
('SV005', 'HP001', '2024-09-05', 1, 9.50),
('SV005', 'HP003', '2025-01-15', 2, 9.00),
('SV005', 'HP004', '2025-01-15', 2, 8.80),
('SV006', 'HP005', '2025-01-16', 2, 7.00),
('SV007', 'HP002', '2024-09-06', 1, 6.50),
('SV008', 'HP006', '2024-09-07', 1, 9.00),
('SV009', 'HP001', '2024-09-05', 1, 8.00),
('SV009', 'HP004', '2025-01-15', 2, 7.50),
('SV010', 'HP006', '2024-09-07', 1, 8.50);
GO

-- =======================================================================
-- 5. TRUY VẤN KIỂM TRA DỮ LIỆU ĐÃ NẠP
-- =======================================================================

PRINT N'-- 5.1 Danh sách Khoa:';
SELECT MaKhoa, TenKhoa FROM Khoa;

PRINT N'-- 5.2 Danh sách Sinh viên kèm tên Khoa:';
SELECT sv.MaSV, sv.HoTen, sv.NgaySinh, 
       CASE sv.GioiTinh WHEN 1 THEN N'Nam' ELSE N'Nữ' END AS GioiTinh,
       k.TenKhoa, sv.DiemTB, sv.Email
FROM SinhVien sv
INNER JOIN Khoa k ON sv.MaKhoa = k.MaKhoa
ORDER BY sv.MaSV;

PRINT N'-- 5.3 Danh sách Học phần:';
SELECT MaHP, TenHP, SoTinChi FROM HocPhan ORDER BY MaHP;

PRINT N'-- 5.4 Bảng điểm chi tiết các lượt đăng ký:';
SELECT dk.MaSV, sv.HoTen, k.TenKhoa, hp.TenHP, hp.SoTinChi, dk.HocKy, dk.NgayDangKy, dk.Diem
FROM DangKy dk
INNER JOIN SinhVien sv ON dk.MaSV = sv.MaSV
INNER JOIN Khoa k ON sv.MaKhoa = k.MaKhoa
INNER JOIN HocPhan hp ON dk.MaHP = hp.MaHP
ORDER BY dk.HocKy, dk.MaSV;
GO

-- =======================================================================
-- 6. BÀI TẬP TỰ THỰC HIỆN - BÀI 6: KIỂM THỬ CÁC RÀNG BUỘC TOÀN VẸN
--    (Được bọc trong TRY...CATCH để không làm dừng script)
-- =======================================================================
PRINT N'=======================================================================';
PRINT N'-- KIỂM THỬ RÀNG BUỘC TOÀN VẸN (BÀI 6)';
PRINT N'=======================================================================';

-- Thử nghiệm 1: Vi phạm CK_SinhVien_Diem (Điểm = 12.0)
BEGIN TRY
    PRINT N'-- Thử chèn SV có ĐiểmTB = 12 (mong đợi lỗi CK_SinhVien_Diem)...';
    INSERT INTO SinhVien (MaSV, HoTen, NgaySinh, GioiTinh, MaKhoa, DiemTB, Email)
    VALUES ('SV_TEST1', N'Lỗi Điểm', '2005-01-01', 1, 'CNTT', 12.0, 'test1@eaut.edu.vn');
END TRY
BEGIN CATCH
    PRINT N'-> Bắt lỗi thành công: ' + ERROR_MESSAGE();
END CATCH;

-- Thử nghiệm 2: Vi phạm UQ_SinhVien_Email (Trùng email với SV001)
BEGIN TRY
    PRINT N'-- Thử chèn SV trùng Email an@eaut.edu.vn (mong đợi lỗi UQ_SinhVien_Email)...';
    INSERT INTO SinhVien (MaSV, HoTen, NgaySinh, GioiTinh, MaKhoa, DiemTB, Email)
    VALUES ('SV_TEST2', N'Lỗi Email', '2005-01-01', 1, 'CNTT', 8.0, 'an@eaut.edu.vn');
END TRY
BEGIN CATCH
    PRINT N'-> Bắt lỗi thành công: ' + ERROR_MESSAGE();
END CATCH;

-- Thử nghiệm 3: Vi phạm CK_DangKy_HocKy (Học kỳ = 4)
BEGIN TRY
    PRINT N'-- Thử đăng ký với Học kỳ = 4 (mong đợi lỗi CK_DangKy_HocKy)...';
    INSERT INTO DangKy (MaSV, MaHP, HocKy, Diem)
    VALUES ('SV001', 'HP004', 4, 8.0);
END TRY
BEGIN CATCH
    PRINT N'-> Bắt lỗi thành công: ' + ERROR_MESSAGE();
END CATCH;

-- Thử nghiệm 4: Vi phạm FK_SinhVien_Khoa (Khoa không tồn tại)
BEGIN TRY
    PRINT N'-- Thử chèn SV với MaKhoa = KHOA_LA (mong đợi lỗi FK_SinhVien_Khoa)...';
    INSERT INTO SinhVien (MaSV, HoTen, NgaySinh, GioiTinh, MaKhoa, DiemTB, Email)
    VALUES ('SV_TEST4', N'Lỗi Khoa', '2005-01-01', 1, 'KHOA_LA', 8.0, 'test4@eaut.edu.vn');
END TRY
BEGIN CATCH
    PRINT N'-> Bắt lỗi thành công: ' + ERROR_MESSAGE();
END CATCH;

-- Thử nghiệm 5: Kiểm tra DEFAULT ngày đăng ký (Không truyền NgayDangKy -> tự nhận GETDATE())
BEGIN TRY
    PRINT N'-- Thử chèn đăng ký không truyền NgayDangKy (kiểm tra DEFAULT GETDATE)...';
    INSERT INTO DangKy (MaSV, MaHP, HocKy, Diem)
    VALUES ('SV004', 'HP001', 1, 9.0);
    PRINT N'-> Đăng ký thành công, NgayDangKy tự động nhận: ' + CONVERT(VARCHAR, (SELECT NgayDangKy FROM DangKy WHERE MaSV = 'SV004' AND MaHP = 'HP001'), 120);
    DELETE FROM DangKy WHERE MaSV = 'SV004' AND MaHP = 'HP001';
END TRY
BEGIN CATCH
    PRINT N'-> Lỗi: ' + ERROR_MESSAGE();
END CATCH;
GO

-- =======================================================================
-- 7. BÀI TẬP TỰ THỰC HIỆN - BÀI 7: TẠO TÀI KHOẢN SQL SERVER AUTHENTICATION
--    Tài khoản riêng cho ứng dụng WinForms với quyền tối thiểu (db_datareader, db_datawriter)
-- =======================================================================
PRINT N'=======================================================================';
PRINT N'-- THIẾT LẬP TÀI KHOẢN SQL AUTHENTICATION (BÀI 7)';
PRINT N'=======================================================================';

USE master;
GO

IF NOT EXISTS (SELECT name FROM sys.server_principals WHERE name = N'sv_app_user')
BEGIN
    PRINT N'-- Tạo Login sv_app_user trên SQL Server instance...';
    CREATE LOGIN sv_app_user WITH PASSWORD = N'Eaut@2026!', CHECK_POLICY = OFF;
END
GO

USE QLSinhVien;
GO

IF NOT EXISTS (SELECT name FROM sys.database_principals WHERE name = N'sv_app_user')
BEGIN
    PRINT N'-- Tạo User sv_app_user trong CSDL QLSinhVien và gán quyền...';
    CREATE USER sv_app_user FOR LOGIN sv_app_user;
    ALTER ROLE db_datareader ADD MEMBER sv_app_user;
    ALTER ROLE db_datawriter ADD MEMBER sv_app_user;
    PRINT N'-- Đã cấp quyền db_datareader và db_datawriter cho sv_app_user.';
END
GO

-- =======================================================================
-- 8. BÀI TẬP TỰ THỰC HIỆN - BÀI 10: HƯỚNG DẪN SAO LƯU VÀ PHỤC HỒI CSDL
-- =======================================================================
PRINT N'=======================================================================';
PRINT N'-- HƯỚNG DẪN SAO LƯU & PHỤC HỒI CSDL (BÀI 10)';
PRINT N'=======================================================================';
PRINT N'-- Lệnh sao lưu (Backup) CSDL:';
PRINT N'-- BACKUP DATABASE QLSinhVien TO DISK = ''C:\SQLBackup\QLSinhVien.bak'' WITH FORMAT, INIT;';
PRINT N'';
PRINT N'-- Lệnh phục hồi (Restore) CSDL:';
PRINT N'-- USE master;';
PRINT N'-- ALTER DATABASE QLSinhVien SET SINGLE_USER WITH ROLLBACK IMMEDIATE;';
PRINT N'-- RESTORE DATABASE QLSinhVien FROM DISK = ''C:\SQLBackup\QLSinhVien.bak'' WITH REPLACE;';
PRINT N'-- ALTER DATABASE QLSinhVien SET MULTI_USER;';
PRINT N'=======================================================================';
PRINT N'-- HOÀN TẤT KHỞI TẠO CSDL QLSinhVien CHO LAB 7!';
PRINT N'=======================================================================';
GO
