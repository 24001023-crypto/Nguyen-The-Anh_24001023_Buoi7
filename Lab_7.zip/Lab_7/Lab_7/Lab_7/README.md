# BÁO CÁO BÀI TẬP THỰC HÀNH LAB 7
## HỌC PHẦN: LẬP TRÌNH .NET (IT3212)
### TẠO CSDL SQL SERVER, TỔNG QUAN ADO.NET VÀ KẾT NỐI CSDL

---

## 1. CÁC NỘI DUNG ĐÃ THỰC HIỆN

### Mục 6. Bổ sung ràng buộc dữ liệu
- Bảng `SinhVien`: Thêm ràng buộc `UNIQUE` cho cột `Email` (`CONSTRAINT UQ_SinhVien_Email UNIQUE (Email)`).
- Bảng `DangKy`:
  - Thêm giá trị mặc định cho cột `NgayDangKy` (`CONSTRAINT DF_DangKy_Ngay DEFAULT GETDATE()`).
  - Thêm ràng buộc kiểm tra học kỳ thuộc [1, 3] (`CONSTRAINT CK_DangKy_HocKy CHECK (HocKy BETWEEN 1 AND 3)`).
- Kịch bản thử dữ liệu vi phạm (bắt lỗi an toàn bằng `TRY...CATCH` trong tệp `Lab07_QLSinhVien.sql`):
  - Chèn điểm `DiemTB = 12.0` -> Vi phạm `CK_SinhVien_Diem`.
  - Chèn trùng email `an@eaut.edu.vn` -> Vi phạm `UQ_SinhVien_Email`.
  - Chèn học kỳ `HocKy = 4` -> Vi phạm `CK_DangKy_HocKy`.
  - Chèn khoa không tồn tại -> Vi phạm `FK_SinhVien_Khoa`.
  - Chèn đăng ký bỏ trống ngày -> Tự động nhận `GETDATE()`.

---

### Mục 7. Chuỗi kết nối SQL Server Authentication
- Tạo tài khoản SQL Server riêng cho ứng dụng:
  - Login: `sv_app_user` (Mật khẩu: `Eaut@2026!`)
  - User trong `QLSinhVien`: `sv_app_user`
  - Cấp quyền tối thiểu: `db_datareader` (đọc dữ liệu) và `db_datawriter` (ghi/sửa/xóa dữ liệu).
- Hỗ trợ lựa chọn giữa **Windows Authentication** và **SQL Server Authentication** trực tiếp trên màn hình kết nối của ứng dụng WinForms.

---

### Mục 8. Đọc chuỗi kết nối từ `App.config`
- Sử dụng thư viện `System.Configuration` và lớp `ConfigurationManager` trong `DbConnectionFactory.cs`:
  ```csharp
  ConnectionStringSettings setting = ConfigurationManager.ConnectionStrings["QLSinhVienConnection"];
  ```
- Không hard-code chuỗi kết nối trong mã nguồn.
- Tự động lưu chuỗi kết nối mới vào `App.config` khi người dùng kết nối thành công.

---

### Mục 9. Xác thực đăng nhập CSDL khi khởi động & Kiểm tra trạng thái từ Dock
- **Màn hình xác thực kết nối CSDL khi khởi động (`frmDangNhap`)**:
  - Popup 1 lần ngay khi khởi chạy ứng dụng (giống cửa sổ đăng nhập SSMS).
  - Cho phép lựa chọn: **Windows Authentication** hoặc **SQL Server Authentication**.
  - Nhập thông tin: Máy chủ (Server), CSDL (Database), Tên đăng nhập (Username), Mật khẩu (Password).
  - **Kiểm soát truy cập**: Bắt buộc nhập đúng và kết nối thành công mới cho phép vào ứng dụng chính. Nếu thất bại, hiển thị hộp thoại báo lỗi và giữ form để người dùng hiệu chỉnh.
- **Nút "Kiểm tra kết nối" trên Dock (`frmDanhSach`) & Menu "Hệ thống > Kiểm tra kết nối CSDL"**:
  - Chỉ thực hiện kiểm tra trạng thái kết nối hiện tại tới CSDL (không yêu cầu nhập lại thông tin đăng nhập rườm rà).
  - Tự động **POPUP** cửa sổ trạng thái (`frmTrangThaiKetNoi`) hiển thị đầy đủ và duy nhất các thông tin Mục 9:
    1. **Trạng thái (Status)**: `Kết nối thành công (Open)`
    2. **Giao thức kết nối**: `Windows Authentication` hoặc `SQL Server Authentication`
    3. **DataSource**: Tên máy chủ SQL Server đang kết nối (ví dụ: `.` hoặc `.\SQLEXPRESS`)
    4. **Database**: Tên CSDL (`QLSinhVien`)
    5. **ServerVersion**: Phiên bản SQL Server (ví dụ: `15.0.2000.5`)
    6. **State**: Trạng thái kết nối (`Open`)
    7. **Thời gian kết nối**: Thời gian phản hồi thực tế (`ms`)
  - Bấm nút **"Đóng"** để quay về màn hình làm việc.
- **Menu "Hệ thống > Đổi tài khoản kết nối CSDL..."**:
  - Cho phép người dùng chuyển đổi linh hoạt giữa Windows Authentication và SQL Server Authentication bất cứ lúc nào.

---

## 2. CẤU TRÚC THƯ MỤC DỰ ÁN

```text
Lab_7/
├── Lab_7.sln                     # File Solution Visual Studio mở dự án Lab 7
├── Lab_7.slnx                    # File Solution định dạng XML
├── Lab07_QLSinhVien.sql          # Kịch bản SQL Server tạo CSDL, ràng buộc và dữ liệu mẫu
├── README.md                     # Tài liệu hướng dẫn chi tiết
├── generate_diagrams.py          # Script tạo sơ đồ CSDL và ảnh giao diện
├── Images/                       # Thư mục ảnh nộp bài
│   ├── SoDoQuanHe_CSDL.png       # Sơ đồ quan hệ thực thể (ERD)
│   ├── KetQuaTruyVan_DauRa.png   # Kết quả truy vấn dữ liệu mẫu trên SQL Server
│   └── GiaoDien_KiemTraKetNoi.png# Ảnh màn hình đăng nhập CSDL và Popup trạng thái Mục 9
└── Project_A/                    # Dự án WinForms C# (.NET Framework 4.7.2)
    ├── App.config                # Cấu hình chuỗi kết nối (Mục 8)
    ├── Project_A.csproj          # File dự án
    ├── SinhVien.cs               # Lớp thực thể sinh viên (bổ sung Email)
    ├── DAL/
    │   ├── DbConnectionFactory.cs# Lớp kết nối ADO.NET (Mục 5, 7, 8)
    │   └── SinhVienDAL.cs        # Đồng bộ trực tiếp dữ liệu SQL Server vào WinForms
    ├── BUS/
    │   └── SinhVienBUS.cs        # Tầng xử lý nghiệp vụ
    ├── frmMain.cs                # Form Dashboard MDI chính
    ├── frmDanhSach.cs            # Form danh sách sinh viên & nút Kiểm tra kết nối trên dock
    ├── frmDangNhap.cs            # Form đăng nhập xác thực CSDL khi khởi động ứng dụng
    └── frmTrangThaiKetNoi.cs     # Popup thông tin trạng thái kết nối Mục 9
```

---

## 3. HƯỚNG DẪN CHẠY VÀ KIỂM TRA

1. **Khởi tạo CSDL**:
   - Mở SSMS, mở file `Lab07_QLSinhVien.sql`, bấm **F5** (Execute) để khởi tạo toàn bộ CSDL `QLSinhVien`, các bảng, ràng buộc, dữ liệu mẫu, và user SQL Authentication `sv_app_user`.
2. **Khởi chạy ứng dụng**:
   - Mở file `Lab_7.sln` trong Visual Studio 2022, bấm **F5** (Start).
   - Form **Đăng nhập CSDL** (`frmDangNhap`) sẽ popup đầu tiên.
   - Chọn phương thức kết nối:
     - **Windows Authentication**: Kết nối trực tiếp bằng quyền Windows hiện hành.
     - **SQL Server Authentication**: Nhập User `sv_app_user` và Mật khẩu `Eaut@2026!`.
   - Bấm **Đăng nhập**: Ứng dụng kiểm tra kết nối, nếu hợp lệ sẽ lưu cấu hình vào `App.config` và mở màn hình chính Dashboard.
3. **Kiểm tra trạng thái kết nối CSDL (Mục 9)**:
   - Trên thanh dock của danh sách hoặc menu **Hệ thống > Kiểm tra kết nối CSDL**, bấm nút **Kiểm tra kết nối**.
   - Cửa sổ `frmTrangThaiKetNoi` sẽ popup hiển thị trực quan thông số Mục 9 (Status, Giao thức, DataSource, Database, ServerVersion, State, Thời gian kết nối ms).
   - Bấm **Đóng** để tiếp tục thao tác với danh sách sinh viên đã đồng bộ từ CSDL.
